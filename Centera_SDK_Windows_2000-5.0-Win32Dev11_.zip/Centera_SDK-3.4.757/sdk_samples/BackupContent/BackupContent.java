import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import com.filepool.fplibrary.FPClip;
import com.filepool.fplibrary.FPTag;
import com.filepool.fplibrary.FPLibraryConstants;
import com.filepool.fplibrary.FPLibraryException;
import com.filepool.fplibrary.FPPool;

/*****************************************************************************
 *
 * Copyright (c) 2001-2006 EMC Corporation All Rights Reserved
 *
 * BackupContent.java
 *
 * Using the Centera Java API and raw read to backup a C-Clip and it's blobs
 * to the local filesystem.
 *
 * This sourcefile contains the intellectual property of EMC Corporation or
 * is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to
 * the terms and conditions of the License Agreement.
 *
 ****************************************************************************/

/**
 * <p> 
 * Title: BackupContent
 * </p>
 * <p>
 * Description: Using the Centera Java API and raw read to backup a C-Clip
 * and it's blobs to the local filesystem.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * <p>
 * Company: EMC Corp.
 * </p>
 */
public class BackupContent {

	/**
	 * main
	 * 
	 */
	public static void main(String[] args) {
		int BUFFER_SIZE = 16384;
		int exitCode = 0;
		String appName="Backup Content Sample";
	    String appVersion="3.1";
		String poolAddress = "us1cas1.centera.org,us1cas2.centera.org";
		String backupDir = ".";
		InputStreamReader inputReader = new InputStreamReader(System.in);
		BufferedReader stdin = new BufferedReader(inputReader);

		try {

		  /*Stores your application's name and version for registration on Centera
	       This call should be made one time, before the FPPoolOpen() call,
	       for each application that interfaces with centera
	       *
	       Applications can also be registered via the environment variables 
	       FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
	       will override what is set through environment variable.
		   */
		    FPPool.RegisterApplication(appName,appVersion);
			    
			// Prompt user for cluster to connect to
			System.out.print("Address of cluster[" + poolAddress + "]: ");
			String answer = stdin.readLine();
 
			if (!answer.equals(""))
				poolAddress = answer;

			System.out.println(
				"Connecting to Centera cluster(" + poolAddress + ")");

			// New feature for 2.3 lazy pool open
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_OPENSTRATEGY,
				FPLibraryConstants.FP_LAZY_OPEN);

			// open cluster connection
			FPPool thePool = new FPPool(poolAddress);

			// Prompt user for clip ID we intend to backup
			System.out.print("clip ID to backup: ");
			String clipID = stdin.readLine();

			if (clipID.equals(""))
				throw new IllegalArgumentException("Invalid answer.");

			// check clip existence
			if (!FPClip.Exists(thePool, clipID)) {
				throw new IllegalArgumentException(
					"ClipID \""
						+ clipID
						+ "\" does not exist on this Centera cluster.");
			}

			// Prompt user for save to directory
			System.out.print("Directory to save file in[" + backupDir + "]: ");
			answer = stdin.readLine();

			if (!answer.equals(""))
				backupDir = answer;

			// open the clip in read-only mode
			System.out.print("Opening C-Clip with ID \"" + clipID + "\"... ");

			FPClip theClip =
				new FPClip(thePool, clipID, FPLibraryConstants.FP_OPEN_FLAT);

			System.out.println("Ok.");

			// read the raw CDF data to an output stream
			System.out.print("Reading C-Clip data... ");

			ByteArrayOutputStream rawData =
				new ByteArrayOutputStream(BUFFER_SIZE);

			theClip.RawRead(rawData);

			System.out.println("Ok.");

			// output CDF data to stdout
			System.out.println("\n" + rawData.toString());

			// save CDF data to file named <clip ID>.xml
			String saveFilename = backupDir + File.separator + clipID + ".xml";

			FileOutputStream theFile = new FileOutputStream(saveFilename);

			theFile.write(rawData.toByteArray());

			theFile.close();
			System.out.println(
				"CDF data has been written to \""
					+ saveFilename
					+ "\" successfully.");

			// now output any blobs on the Tags
			FPTag theTag;
			int tagNum = 0;
			String blobFileName = backupDir + File.separator + clipID  + ".tag";
			
			while ((theTag = theClip.FetchNext()) != null)	
			{
				int blobStatus = theTag.BlobExists();
				
				if (blobStatus != 0)
				{
					if (blobStatus == 1)
					{
						// Available to read
						theFile = new FileOutputStream(blobFileName + tagNum);
						theTag.BlobRead(theFile);
						theFile.close();
						System.out.println("Saved blob content to " + blobFileName + tagNum);
					}
					else
						System.out.println("Blob on Tag " + tagNum
								+ " is currently unavailable and has NOT been exported.");					
				}
				theTag.Close();
				tagNum++;
			}

			theClip.Close();

			// Always close the Pool connection when finished.
			thePool.Close();
			System.out.println(
				"\nClosed connection to Centera cluster (" + poolAddress + ")");

		} catch (FPLibraryException e) {
			System.err.println("Centera SDK Error: " + e.getMessage());
			exitCode = e.getErrorCode();
		} catch (IllegalArgumentException e) {
			System.err.println("Error: " + e.getMessage());
			exitCode = -1;
		} catch (IOException e) {
			System.err.println("IO Error: " + e.getMessage());
			exitCode = -1;
		}

		System.exit(exitCode);
	}
}
