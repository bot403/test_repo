/******************************************************************************\
*
* Copyright (c) 2001-2006 EMC Corporation
* All Rights Reserved
*
*
* RestoreContent Source File Build Version @version.full@
*
* This sourcefile contains the intellectual property of EMC Corporation
* or is licensed to EMC Corporation from third parties. Use of this sourcefile
* and the intellectual property contained therein is expressly limited to the
* terms and conditions of the License Agreement.
*
\******************************************************************************/

/*
* Example - Using The Centera Access API To Restore Content to a Pool.
*
* This example shows how to restore content to the target Pool.
* The IP address(es) of the access node(s) to the target Pool and the file containing
* the data of the to-be-restored C-Clip are entered via the command line.
* The content will be restored to the target Pool and the status of the process will be
* displayed on the screen.
*
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <malloc.h>

/*
* The standard header file for the Centera access API.
* This includes all function prototypes and type
* definitions needed to use the access API.
*/
#include <FPAPI.h>

#define BUFSIZE (128 + 1)
#define MAX_NAME_SIZE (128+1)

char **inputData(const char *, const int, const char *[], const char *[], const char *[]);
FPInt checkAndPrintError(const char *);

int main(int argc, char *argv[])
{
    FPClipID clipID;
    FPPoolRef poolRef;
    FPInt retCode = 0;
    int index;
    const char *appVersion="3.1";
    const char *appName = "Restore Content";
    const int numParameters = 2;
    const char *prompts[] = { "Enter the IP address or DNS name of the cluster(s)",
        "Enter the filename (e.g. clipID.xml) to be restored to the pool "};
    const char *choices[] = { "" , "" };
    const char *defaults[] = { "us1cas1.centera.org,us1cas2.centera.org", "" };

    /* Verify the input options */
    char **values = inputData(appName, numParameters, prompts, choices, defaults);
    const char *poolAddress = values[0];
    const char *fileName = values[1];

    /* Get the C-Clip ID from the name of the input file - content address with .xml appended */
    if (sscanf(fileName, "%[^.].xml", clipID) != 1)
    {
        fprintf(stderr, "Invalid File Name\n");
        exit(1);
    }

    /*Stores your application's name and version for registration on Centera
    This call should be made one time, before the FPPoolOpen() call,
    for each application that interfaces with centera
    *
    Applications can also be registered via the environment variables 
    FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
    will override what is set through environment variable.
    */
    FPPool_RegisterApplication(appName,appVersion);
    retCode = checkAndPrintError("Application Registration Error: ");

    /* Use LazyOpen option for opening pools as it is more efficient */
    FPPool_SetGlobalOption(FP_OPTION_OPENSTRATEGY, FP_LAZY_OPEN);

    /*
    * Open up a Pool
    */
    poolRef = FPPool_Open(poolAddress);
    retCode = checkAndPrintError("Pool Open Error: ");
    if (!retCode)
    {
        /* Create a stream to read from a file */
        FPStreamRef streamRef = FPStream_CreateFileForInput(fileName, "rb", 16 * 1024);
        retCode = checkAndPrintError("Create Stream For Input: ");
        if (!retCode)
        {
            /* Restore the C-Clip to a Pool */
            FPClipRef clipRef = FPClip_RawOpen(poolRef, clipID, streamRef, 0);
            retCode = checkAndPrintError("C-Clip Open Error: ");
            if (!retCode)
            {
                FPBool finished = false;
                int tagNumber = 0;
                FPClipID restoreClipID;
                FPTagRef myTag;
                char tagFileName[MAX_NAME_SIZE];

                FPStream_Close(streamRef);
                retCode = checkAndPrintError("Stream Close Error: ");

                /* Read any blob data associated with each tag of the clip */
                do
                {
                    myTag = FPClip_FetchNext(clipRef);
                    retCode = checkAndPrintError("Fetch Next Tag Error: ");

                    if (myTag == 0)
                    {
                        finished = true;
                    }
                    else
                    {

                        if (FPTag_BlobExists(myTag) != -1)
                        {
                            sprintf(tagFileName, "%s.Tag%d", clipID, tagNumber);
                            streamRef = FPStream_CreateFileForInput(tagFileName, "rb", 16 * 1024);
                            retCode = checkAndPrintError("Tag Stream Create Error: ");

                            if (!retCode)
                            {
                                FPTag_BlobWrite(myTag, streamRef, FP_OPTION_DEFAULT_OPTIONS);
                                retCode = checkAndPrintError("Blob Read Error on Tag: ");

                                if (!retCode)
                                    fprintf(stdout, "Tag %d restored from file %s\n", tagNumber, tagFileName);

                                FPStream_Close(streamRef);
                                retCode = checkAndPrintError("Stream Close Error: ");
                            }

                            FPTag_Close(myTag);
                            retCode = checkAndPrintError("Stream Close Error: ");
                        }
                    }

                    tagNumber++;

                } while (!finished);

                /* Write the unmodified C-Clip to the Pool*/
                FPClip_Write(clipRef, restoreClipID);
                retCode = checkAndPrintError("C-Clip Write Error: ");
                if (!retCode)
                {
                    if (strcmp(clipID, restoreClipID) == 0)
                    {
                        fprintf(stdout,"\nC-Clip %s has been restored to the Pool\n", restoreClipID);
                    }
                    else
                    {
                        fprintf(stderr,"Error: clip was modified! Restored C-Clip ID %s does not match original ClipID %s\n", restoreClipID, clipID);
                    }
                }

                FPClip_Close(clipRef);
                retCode = checkAndPrintError("C-Clip Close Error: ");
            }

            FPPool_Close(poolRef);
            retCode = checkAndPrintError("Pool Close Error: ");
        }
    }

    for (index=0;index<numParameters; index++)
    {
        free(values[index]);
    }
    free(values);
    return retCode;
}

char **inputData(const char *header,
                 const int  numParameters,
                 const char *prompts[],
                 const char *validOptions[],
                 const char *defaults[])
{
    int i;
    char buffer[BUFSIZE];
    char **values = (char **) malloc(numParameters * sizeof(char *));

    fprintf(stderr, "Enter values or leave blank to use defaults:\n\n");

    i = 0;
    while (i < numParameters)
    {
        FPBool valid = false;

        if (*prompts[i] !=  '\0')
            fprintf(stderr, "%s: ", prompts[i]);

        if (*validOptions[i] != '\0')
            fprintf(stderr, " Valid options [%s] ", validOptions[i]);

        if (*defaults[i] != '\0')
            fprintf(stderr, " <%s> ", defaults[i]);

        fgets(buffer, sizeof(buffer), stdin);
        buffer[strlen(buffer) - 1] = '\0';  /* Remove the terminating \n */

        if (buffer[0] == '\0')
        {
            if (*defaults[i] != '\0') /* Accept the default */
            {
                values[i] = (char *) malloc((strlen(defaults[i])+1) * sizeof(char));
                strcpy(values[i], defaults[i]);
                valid = true;
            }
            else
            {
                fprintf(stdout, "There is no default value - please enter data\n");
            }
        }
        else
        {
            /* Test that data is valid */
            if (*validOptions[i] == '\0') /* No choices to validate so accept what user entered */
            {
                values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                strcpy(values[i], buffer);
                valid = true;
            }
            else
            {
                const char *substr = (const char *) strstr((char *) validOptions[i], buffer);

                if (substr) /* Input is within the validOptions string - check the if it is the whole value */
                {
                    const char *optionEnd =  strchr(substr, '|');

                    if (optionEnd)
                    {
                        int length = (int) (optionEnd - substr);

                        if (length == (int) strlen(buffer))
                            valid = true;
                    }
                    else
                        valid = true;
                }


                if (!valid)
                    fprintf(stderr, "%s is not in valid choices: [%s]\n", buffer, validOptions[i]);
                else
                {
                    values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                    strcpy(values[i], buffer);
                }
            }
        }
        if (valid)
            ++i;
    }

    return values;
}

FPInt checkAndPrintError(const char *errorMessage)
{
    /* Get the error code of the last SDK API function call */
    FPInt errorCode = FPPool_GetLastError();
    if (errorCode != ENOERR)
    {
        FPErrorInfo errInfo;
        fprintf(stderr, errorMessage);
        /* Get the error message of the last SDK API function call */
        FPPool_GetLastErrorInfo(&errInfo);
        if (!errInfo.message) /* the human readable error message */
            fprintf(stderr, "%s\n", errInfo.errorString);
        else if (!errInfo.errorString) /* the error string corresponds to an error code */
            fprintf(stderr, "%s\n", errInfo.message);
        else
            fprintf(stderr, "%s%s%s\n",errInfo.errorString," - ",errInfo.message);
    }

    return errorCode;
}

