/******************************************************************************\
 *
 * Copyright (c) 2001-2006 EMC Corporation
 * All Rights Reserved
 *
 * GenericStreamWrite.c
 *
 * GenericStreamWrite Source File Build Version @version.full@
 *
 * This sourcefile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/

/*
 * Example - Using The Centera Access API To Write To A Generic Stream.
 *
 * This example shows how to create an input generic stream.
 * The IP address(es) of the access node(s) to the cluster and the file to store in
 * the Centera are entered via the command line.
 * An input generic stream will be created and the file will be stored in the Centera through
 * the created generic stream.
 *
 *
 */

/* use 64-bit stat & seek on Win32 */
#if defined(_MSC_VER)   /* Visual C++ */
#  include <io.h>
#  define STAT    _stati64
#  define SEEK64  _lseeki64
#  define FILENO  _fileno
#else
#  define STAT    stat
#  define SEEK64  fseek
#  define FILENO
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <FPAPI.h>
#include <malloc.h>


typedef struct {
    FILE *fp;
    FPLong fileSize;
    FPLong sizeOfBuffer;
} StreamUserData;

#define MAX_NAME_SIZE (128+1)
#define CHARBUFSIZE (128 + 1)

char **inputData(const char *, const int, const char *[], const char *[], const char *[]);
FPInt checkAndPrintError(const char *);

static long close_callback(FPStreamInfo *);
static long in_prepare_buffer_callback(FPStreamInfo *);
static long in_set_mark_callback(FPStreamInfo *);
static long in_reset_mark_callback(FPStreamInfo *);

int writeBlobToClip(const FPTagRef, const char *, FPInt, int);

int main(int argc, char* argv[])
{
    FPPoolRef poolRef;
    FPInt retCode = 0;
    int index;
    const char *appVersion="3.1";
    const char *appName = "Generic Stream Write";
    const int numParameters = 4;
    const char *prompts[] = { "Enter the IP address or DNS name of the cluster(s)",
                              "Enter the name of the file to be written",
                              "Calculate ID before streaming data?",
                              "Force 'unknown stream length' logic?" };
    const char *choices[] = { "" , "", "Y|N", "Y|N" };
    const char *defaults[] = { "us1cas1.centera.org,us1cas2.centera.org", "", "N", "N" };


    /* Verify the input options */
    char **values = inputData(appName, numParameters, prompts, choices, defaults);
    const char *poolAddress = values[0];
    const char *fileName = values[1];
    int   blobWriteSuccessful = 0;
    FPInt strategy = (*values[2] == 'N') ? FP_OPTION_CLIENT_CALCID_STREAMING : FP_OPTION_CLIENT_CALCID;
    int   useUnknownStreamLen = (*values[3] == 'N') ? 0 : 1;

    (void) argc; (void) argv; /* avoid 'unused' warnings */


    /*Stores your application's name and version for registration on Centera
    This call should be made one time, before the FPPoolOpen() call,
    for each application that interfaces with centera
    *
    Applications can also be registered via the environment variables 
    FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
    will override what is set through environment variable.
    */
    FPPool_RegisterApplication(appName,appVersion);
    retCode = checkAndPrintError("Application Registration Error: ");

    /* New in 2.3 - use LazyOpen option for opening pools as it is more efficient */
    FPPool_SetGlobalOption(FP_OPTION_OPENSTRATEGY, FP_LAZY_OPEN);

    /*
     * Open up a Pool
     */
    poolRef = FPPool_Open(poolAddress);
    retCode = checkAndPrintError("Pool Open Error: ");
    if (!retCode)
    {
        FPClipID clipID;
        FPClipRef clipRef = FPClip_Create(poolRef, "GenericStreamClip");
        FPInt retCode = checkAndPrintError("C-Clip Create Error: ");
        if (!retCode)
        {
            FPTagRef topTag = FPClip_GetTopTag(clipRef);
            FPInt retCode = checkAndPrintError("Get Top Tag Error: ");
            if (!retCode)
            {
                /*
                 * Create a "child" tag on the topTag to hold the data
                 */
                FPTagRef dataTagRef = FPTag_Create(topTag,"dataTag");
                retCode = checkAndPrintError("Tag Create Error: ");
                if (!retCode)
                {
                    retCode |= writeBlobToClip(dataTagRef, fileName, strategy, useUnknownStreamLen);
                    blobWriteSuccessful = (retCode == 0);
                    
                    FPTag_Close(dataTagRef);
                    retCode |= checkAndPrintError("Blob Tag Close Error: ");
                }

                FPTag_Close(topTag);
                retCode |= checkAndPrintError("Tag Close Error: ");
            }

            if (blobWriteSuccessful)
            {
                FPClip_SetRetentionPeriod(clipRef, FP_NO_RETENTION_PERIOD);
                retCode = checkAndPrintError("Set RetentionPeriod Error: ");

                FPClip_SetDescriptionAttribute(clipRef, "OriginalFilename", fileName);
                retCode = checkAndPrintError("Set OriginalFilename DescriptionAttribute Error: ");

                /*
                 * Write the C-Clip to the Pool
                 */
                FPClip_Write(clipRef, clipID);
                retCode = checkAndPrintError("C-Clip Write Error: ");
                if (!retCode)
                    fprintf(stdout, "The C-Clip ID: %s\n", clipID);
            }
            FPClip_Close(clipRef);
            retCode = checkAndPrintError("C-Clip Close Error: ");
        }
    }

    /*
     * Close the pool
     */
    FPPool_Close(poolRef);
    retCode = checkAndPrintError("Pool Close Error: ");

    fprintf(stdout, "Press <enter> to continue.\n");
    (void) getchar();

    for (index=0;index<numParameters; index++)
    {
         free(values[index]);
    }
    free(values);

    return retCode;
}

/*
 * Write the file to the Centera as a blob of the C-Clip
 */
int writeBlobToClip(const FPTagRef tagRef, const char *fileName, FPInt strategy, int useUnknownStreamLen)
{
    FPLong fileSize = 0;
    FPInt retCode = 0;
    FILE *fp = fopen(fileName, "rb");

    struct STAT sbuf;
    memset((char *)&sbuf, 0, sizeof(sbuf));
    retCode = STAT(fileName, &sbuf);

    if (!retCode)
    {
        FPStreamRef streamRef = 0;
        StreamUserData *userData = (StreamUserData *)calloc(1, sizeof(StreamUserData));

        fileSize = sbuf.st_size;

        if (userData)
        {
            userData->fp = fp;
            userData->fileSize = fileSize;
            userData->sizeOfBuffer = 0;
            streamRef = FPStream_CreateGenericStream(in_prepare_buffer_callback,    /* Prepare */
                                                     (const FPStreamProc)  0,      /* Complete */
                                                     in_set_mark_callback,          /* Set Mark */
                                                     in_reset_mark_callback,        /* Reset Mark */
                                                     close_callback,                /* Close */
                                                     userData);

            retCode = checkAndPrintError("Create Generic Stream Error: ");

            if (!retCode)
            {
                FPStreamInfo *streamInfo = FPStream_GetInfo(streamRef);
                retCode |= checkAndPrintError("Get StreamInfo Error: ");

                if (!retCode)
                {
                    streamInfo->mReadFlag = true;
                    streamInfo->mStreamLen = (useUnknownStreamLen) ? -1 : fileSize;
                    streamInfo->mStreamPos = 0;

                    FPTag_BlobWrite(tagRef, streamRef, strategy);
                    retCode |= checkAndPrintError("Blob Write Error: ");
                }

                FPStream_Close(streamRef);
                retCode |= checkAndPrintError("Generic Stream Close Error: ");

            }
        }
        else
            retCode = -1;

        fclose(fp);
    }

    return retCode;
}

/***********************************************************
 * input stream callback functions
 ***********************************************************/


/*
 * Prepare a buffer that contains the data that the stream can use.
 */
static long in_prepare_buffer_callback(FPStreamInfo *streamInfo)
{
    FPLong numRead = 0;

    long retCode = ENOERR;
    StreamUserData *userData = (StreamUserData *)streamInfo->mUserData;

    FILE *fp = userData->fp;

    /* If this is the first time through we need to allocate the buffer */
    if (streamInfo->mBuffer == NULL)
    {
        /* If we are using CLIENT_CALC_ID, the the Transfer Length passed in will be 100MB in order
         * to be able to calculate the MD5 for a internal full blob segment.
         *
         * Naturally we don't want to allocate this much memory to a buffer unless we have to, so let's try and
         * minimise the size.
         */
        if (streamInfo->mStreamLen > 0)
        {
            /* We know the length of the stream, so if this is smaller than the Transfer Length 
             * then just allocate a buffer big enough to hold it.
             */
            userData->sizeOfBuffer = ((streamInfo->mTransferLen > streamInfo->mStreamLen) 
                                      ? streamInfo->mStreamLen : streamInfo->mTransferLen) * sizeof(char);
        }
        else
        {
            /*
             * In this example, we know the file size so allocate a buffer that is just large enough to hold our
             * if this is less than 100MB in size.
             *
             * Typically you would not be know this information (otherwise you would have set the Stream Length
             * up front) but this demonstrates the logic involved if you need to do this and does not force us
             * to allocate the 100MB.
             */
            userData->sizeOfBuffer = ((streamInfo->mTransferLen > userData->fileSize) 
                                      ? userData->fileSize : streamInfo->mTransferLen) * sizeof(char);
        }

        streamInfo->mBuffer = (char *) malloc((unsigned int) userData->sizeOfBuffer);
    }
    else if (userData->sizeOfBuffer != streamInfo->mTransferLen)
    {
        /* This is the final block, so free up our buffer and allocate a smaller buffer
         * sufficient to hold this last piece.
         */
        free(streamInfo->mBuffer);
        userData->sizeOfBuffer = streamInfo->mTransferLen * sizeof(char);
        streamInfo->mBuffer = (char *) malloc((unsigned int) userData->sizeOfBuffer);
    }

    if (NULL == streamInfo->mBuffer)
    {
        fprintf(stderr, "Error allocating transfer buffer of %d bytes, aborting stream.\n",
                (int) userData->sizeOfBuffer);
        return -1;
    }
    
    numRead = fread((char *)streamInfo->mBuffer, sizeof(char), (unsigned int) userData->sizeOfBuffer, fp);
    streamInfo->mStreamPos      +=  numRead;
    streamInfo->mTransferLen    =   numRead;

    /*
     * Set mAtEOF to true if we have reached the end of the file
     */
    streamInfo->mAtEOF = (FPBool) (streamInfo->mStreamPos >= userData->fileSize);

    return retCode;
}

/*
 * Called when data has been successfully read from the buffer
 * In the case of an input stream, the callback function notifies us that the SDK has finished
 * with the input buffer. We can then unlock or deallocate the buffer if neccessary. We are
 * not doing anything with it in this example so leave it unimplemented and set to null when cretaing the stream.
 *
 * static long in_complete_callback(FPStreamInfo *streamInfo)
 *
 */

/*
 * Called to set the current position in the data stream. This method tells the
 * stream to go back to the marked position in the stream, which in this example is
 * easy as we just need to seek back in the file.
 *
 * Not always so easy to do, and you need to be prepared to go back up to 100 MB.
 * It is of the UTMOST importance that this is implemented properly and does exactly as requested
 * i.e. reposition properly within the stream.
 *
 * If this is very difficult to achieve in your own practical scenario then you should NOT implement
 * marking support - the Set and Reset Mark callbacks should be set to null pointers on stream creation.
 *
 * !!!!!! NEVER implement the marker callbacks to simply return ENOERR!!!!!!!!!
 */
static long in_reset_mark_callback(FPStreamInfo *streamInfo)
{
    StreamUserData *userData = (StreamUserData *)streamInfo->mUserData;

    if (SEEK64(FILENO(userData->fp), streamInfo->mMarkerPos, SEEK_SET) < 0)
    {
        fprintf(stderr, "Error attempting to seek to position %ld, aborting stream.\n",
                (long int) streamInfo->mMarkerPos);
        return -1;
    }

    streamInfo->mStreamPos = streamInfo->mMarkerPos;
    return ENOERR;
}

/*
 * Called to mark current position in the data stream. The SDK sometimes needs to return
 * to an earlier position in the stream. To do this, it sets a 'mark' at the current
 * position in the stream. If necessary, the SDK can return later to that position by
 * calling the resetMarkerProc
 */

static long in_set_mark_callback(FPStreamInfo *streamInfo)
{
    streamInfo->mMarkerPos = streamInfo->mStreamPos;

    return ENOERR;
}


/*
 * Finalize stream - free up the buffer.
 */
static long close_callback(FPStreamInfo *streamInfo)
{
    StreamUserData *userData = (StreamUserData *)streamInfo->mUserData;

    if (NULL != streamInfo->mBuffer)
    {
        free(streamInfo->mBuffer);
        userData->sizeOfBuffer = 0;
        streamInfo->mBuffer = NULL;
    }
    return ENOERR;
}


/*
 *
 * user input  processing routine
 *
 */

char **inputData(const char *header,
                 const int numParameters,
                 const char *prompts[],
                 const char *validOptions[],
                 const char *defaults[])
{
    int i;
    char buffer[CHARBUFSIZE];
    char **values = (char **) malloc(numParameters * sizeof(char *));

    (void) header; /* just to avoid 'unused' warning */

    fprintf(stderr, "Enter values or leave blank to use defaults:\n\n");

    i = 0;
    while (i < numParameters)
    {
        FPBool valid = false;

        if (*prompts[i] !=  '\0')
            fprintf(stderr, "%s: ", prompts[i]);

        if (*validOptions[i] != '\0')
            fprintf(stderr, " Valid options [%s] ", validOptions[i]);

        if (*defaults[i] != '\0')
            fprintf(stderr, " <%s> ", defaults[i]);

        fgets(buffer, sizeof(buffer), stdin);
        buffer[strlen(buffer) - 1] = '\0';  /* Remove the terminating \n */

        if (buffer[0] == '\0')
        {
            if (*defaults[i] != '\0') /* Accept the default */
            {
                values[i] = (char *) malloc((strlen(defaults[i])+1) * sizeof(char));
                strcpy(values[i], defaults[i]);
                valid = true;
            }
            else
            {
                fprintf(stdout, "There is no default value - please enter data\n");
            }
        }
        else
        {
            /* Test that data is valid */
            if (*validOptions[i] == '\0') /* No choices to validate so accept what user entered */
            {
                values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                strcpy(values[i], buffer);
                valid = true;
            }
            else
            {
                const char *substr = (const char *) strstr((char *) validOptions[i], buffer);

                if (substr) /* Input is within the validOptions string - check the if it is the whole value */
                {
                    const char *optionEnd =  strchr(substr, '|');

                    if (optionEnd)
                    {
                        int length = (int) (optionEnd - substr);

                        if (length == (int) strlen(buffer))
                            valid = true;
                    }
                    else
                        valid = true;
                }


                if (!valid)
                    fprintf(stderr, "%s is not in valid choices: [%s]\n", buffer, validOptions[i]);
                else
                {
                    values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                    strcpy(values[i], buffer);
                }
            }
        }
        if (valid)
            ++i;
    }

    return values;
}

FPInt checkAndPrintError(const char *errorMessage)
{
    /* Get the error code of the last SDK API function call */
    FPInt errorCode = FPPool_GetLastError();
    if (errorCode != ENOERR)
    {
        FPErrorInfo errInfo;
        fprintf(stderr, errorMessage);
        /* Get the error message of the last SDK API function call */
        FPPool_GetLastErrorInfo(&errInfo);
        if (!errInfo.message) /* the human readable error message */
            fprintf(stderr, "%s\n", errInfo.errorString);
        else if (!errInfo.errorString) /* the error string corresponds to an error code */
            fprintf(stderr, "%s\n", errInfo.message);
        else
            fprintf(stderr, "%s%s%s\n",errInfo.errorString," - ",errInfo.message);
    }

    return errorCode;
}
