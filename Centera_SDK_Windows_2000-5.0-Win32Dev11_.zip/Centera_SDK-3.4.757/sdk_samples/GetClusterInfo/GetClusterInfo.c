/******************************************************************************\
 *
 * Copyright (c) 2001-2006 EMC Corporation
 * All Rights Reserved
 *
 * GetClusterInfo.c
 *
 * GetClusterInfo Source File Build Version @version.full@
 *
 * This sourcefile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/

/*
 * Example - Using The Centera Access API To Retrieve The Pool-related Information
 *
 * This example shows how to connect to a cluster and get the Pool capabilities and properties
 * information. User is prompted to enter the IP address(es) of the access node(s) of the
 * cluster. The Pool capabilities and properties information will then be retrieved and
 * displayed on the screen.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>

/*
 * The standard header file for the Centera access API.
 * This includes all function prototypes and type
 * definitions needed to use the access API.
 */
#include <FPAPI.h>

/* 64-bit printf formats */
#if defined(_MSC_VER)   /* Visual C++ */
#  define L64D "%I64d"
#else
#  define L64D "%lld"
#endif

#define BUFSIZE (256 + 1)

FPInt checkAndPrintError(const char *);
char **inputData(const char *, const int, const char *[], const char *[], const char *[]);
FPBool sizeMatch(char *buf, size_t bufSize) {return ((strlen(buf) + 1) == bufSize); }

void retrievePoolInfo(const FPPoolRef);
void retrievePropertyInfo(const FPPoolRef, const char *);
void retrieveCapabilityInfo(const FPPoolRef);

int main(int argc, char *argv[])
{
    char *poolAddress;
    FPPoolRef poolRef;
    int errorDetected;
    int index;
    const char *appVersion="3.1";
    const char *appName = "Cluster Info";
    const int numParameters = 1;
    const char *prompts[] = { "Enter the IP address or DNS name of the cluster(s)" };
    const char *choices[] = { "" };
    const char *defaults[] = { "us1cas1.centera.org,us1cas2.centera.org" };


    /* Verify the input options */
    char **values = inputData(appName, numParameters, prompts, choices, defaults);
    poolAddress = values[0];


    /*Stores your application's name and version for registration on Centera
    This call should be made one time, before the FPPoolOpen() call,
    for each application that interfaces with centera
    *
    Applications can also be registered via the environment variables 
    FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
    will override what is set through environment variable.
    */
    FPPool_RegisterApplication(appName,appVersion);
    errorDetected = checkAndPrintError("Application Registration Error: ");

    /* New in 2.3 - use LazyOpen option for opening pools as it is more efficient */
    FPPool_SetGlobalOption(FP_OPTION_OPENSTRATEGY, FP_LAZY_OPEN);

    /*
     * Open up a Pool
     */
    poolRef = FPPool_Open(poolAddress);
    errorDetected = checkAndPrintError("Pool Open Error: ");

    /* Successfully opened up the Pool */
    if (!errorDetected)
    {
        /* Retrieve Pool information */
        retrievePoolInfo(poolRef);

        /* Retrieve Pool properties information */
        retrievePropertyInfo(poolRef, poolAddress);

        /* Retrieve Pool capabilities information */
        retrieveCapabilityInfo(poolRef);

        /*
         * Close the pool
         */
        FPPool_Close(poolRef);
        errorDetected = checkAndPrintError("Pool Close Error: ");
    }

    for (index=0;index<numParameters; index++)
    {
         free(values[index]);
    }
    free(values);
    return errorDetected;
}

/*
 * Retrieve the information of the given Pool and display the information on the screen.
 * With the exception of the poolInfoVersion, all Pool information can only be set using
 * CLI - a command line tool of Centera
 */
void retrievePoolInfo(const FPPoolRef poolRef)
{
    FPPoolInfo poolInfo;
    int errorDetected;
    char fmtbuf[BUFSIZE];

    /*
     * Retrieve the Pool Info. The pool information will be saved to the FPPoolInfo structure
     */
    FPPool_GetPoolInfo(poolRef, &poolInfo);
    errorDetected = checkAndPrintError("Get Pool Info Error: ");
    if (!errorDetected)
    {
        fprintf(stdout, "The Pool Information\n");
        fprintf(stdout, "=====================\n");

        /* Retrieve the ID of the cluster */
        fprintf(stdout, "Cluster Identifier:\t\t\t\t%s\n", poolInfo.clusterID);

        /* Retrieve the name of the cluster */
        fprintf(stdout, "Cluster Name:\t\t\t\t\t%s\n", poolInfo.clusterName);

        /* Retrieve the version of the current FPPoolInfo structure */
        fprintf(stdout, "Pool Info Version:\t\t\t\t%d\n", (int)poolInfo.poolInfoVersion);

        /* Retrieve the Pool Software version number */
        fprintf(stdout, "Cluster Software (CentraStar version):\t\t%s\n", poolInfo.version);

        /*
         * Retrieve the total usable capacity of all online nodes
         * Output from the CLI and Centera Viewer (Centera tools) report 1000 bytes as
         * 1Kbytes. When converting the capacity as returned by the SDK to your application,
         * we recommend using the same conversion rate
         */
        sprintf(fmtbuf, "Total Usable Capacity In The Pool (bytes):\t%s\n", L64D);
        fprintf(stdout, fmtbuf, poolInfo.capacity);

        /*
         * Retrieve the total free space of the Pool
         * The function returns an approximate value for the free space. The returned value
         * can vary within 2% when compared to subsequent calls of the function. The free space
         * reflects the total amount of usable space on all online nodes to store data mirrored
         */
        sprintf(fmtbuf, "Total Free Space In The Pool (bytes):\t\t%s\n", L64D);
        fprintf(stdout, fmtbuf, poolInfo.freeSpace);

        /* Retrieve the replica address */
        if (poolInfo.replicaAddress && strlen(poolInfo.replicaAddress) > 0)
            fprintf(stdout, "Cluster Replication:\t\t\t\t%s\n",poolInfo.replicaAddress);
        else
            fprintf(stdout, "Cluster Replication:\t\t\t\t%s\n", "not enabled");
    }
}

/*
 * The FPPool_GetIntOption() and FPPool_GetGlobalOption() are used to retrieve the
 * Pool options. The corresponding FPPool_SetIntOption() and FPPool_SetGlobalOption()
 * can be used to set those options.
 */
void retrievePropertyInfo(const FPPoolRef poolRef, const char *poolAddress)
{
    FPInt value;
    char buffer[BUFSIZE];
    int errorDetected = 0;

    fprintf(stdout, "\nThe Pool Properties \n");
    fprintf(stdout, "====================\n");

    /* Display the connection string */
    fprintf(stdout, "Connection String:\t\t\t\t%s\n", poolAddress);

    /* Retrieve the maximum number connections */
    value = FPPool_GetGlobalOption(FP_OPTION_MAXCONNECTIONS);
    errorDetected = checkAndPrintError("Get Maximum Number Of Connections Error: ");
    if (!errorDetected)
        fprintf(stdout, "Maximum Number Of Connections:\t\t\t%d\n", (int) value);

    /* Retrieve the number of times a retry must be executed */
    value = FPPool_GetGlobalOption(FP_OPTION_RETRYCOUNT);
    errorDetected = checkAndPrintError("Get Number Of Retry Attempts Error: ");
    if (!errorDetected)
        fprintf(stdout, "Number Of Retry Attempts:\t\t\t%d\n", (int) value);

    /*
     * Retrieve the time to sleep before the failed API function call should be retried,
     * in milliseconds
     */
    value = FPPool_GetGlobalOption(FP_OPTION_RETRYSLEEP);
    errorDetected = checkAndPrintError("Get Sleep Time Between Retry Attempts Error: ");
    if (!errorDetected)
        fprintf(stdout, "Sleep Time Between Retry Attempts (ms):\t\t%d\n", (int) value);


    /*
     * Retrieve the time to sleep before the failed API function call should be retried,
     * in milliseconds
     */
    value = FPPool_GetGlobalOption(FP_OPTION_CLUSTER_NON_AVAIL_TIME);
    errorDetected = checkAndPrintError("Get Cluster Non Avail Time: ");
    if (!errorDetected)
        fprintf(stdout, "Cluster Non Avail time (ms):\t\t\t%d\n", (int) value);

    /* Embedded blob threshold */
    value = FPPool_GetGlobalOption(FP_OPTION_EMBEDDED_DATA_THRESHOLD);
    errorDetected = checkAndPrintError("Embedded Blob Threshold: ");
    if (!errorDetected)
        fprintf(stdout, "Embedded Blob Threshold (bytes):\t\t%d\n", (int) value);

    /* Retrieve if the collision avoidance enabled */
    value = FPPool_GetIntOption(poolRef, FP_OPTION_DEFAULT_COLLISION_AVOIDANCE);
    errorDetected = checkAndPrintError("Get Collision Avoidance Scheme Error: ");
    if (!errorDetected)
    {
        if (value == 1)
            fprintf(stdout,"Collision Avoidance Enabled:\t\t\t%s\n", "true");
        else
            fprintf(stdout, "Collision Avoidance Enabled:\t\t\t%s\n", "false");
    }

    /* Retrieve if the multi-cluster failover enabled */
    value = FPPool_GetIntOption(poolRef, FP_OPTION_ENABLE_MULTICLUSTER_FAILOVER);
    errorDetected = checkAndPrintError("Get Multi-Cluster Failover Error: ");

    if (!errorDetected)
    {
        if (value == 1)
        {
            fprintf(stdout, "Multi-Cluster Failover Enabled:\t\t\t%s\n", "true");

            fprintf(stdout, "\n\tRead-failover-strategy:\t\t\t%d\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_READ_STRATEGY));
            fprintf(stdout, "\tRead-cluster-strategy:\t\t\t%d\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_READ_CLUSTERS));

            fprintf(stdout, "\tWrite-failover-strategy:\t\t%d\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_WRITE_STRATEGY));
            fprintf(stdout, "\tWrite-cluster-strategy:\t\t\t%d\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_WRITE_CLUSTERS));

            fprintf(stdout, "\tDelete-failover-strategy:\t\t%d\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_DELETE_STRATEGY));
            fprintf(stdout, "\tDelete-cluster-strategy:\t\t%d\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_DELETE_CLUSTERS));

            fprintf(stdout, "\tExists-failover-strategy:\t\t%d\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_EXISTS_STRATEGY));
            fprintf(stdout, "\tExists-cluster-strategy:\t\t%d\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_EXISTS_CLUSTERS));

            fprintf(stdout, "\tQuery-failover-strategy:\t\t%d\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_QUERY_STRATEGY));
            fprintf(stdout, "\tQuery-cluster-strategy:\t\t\t%d\n\n",
                    (int) FPPool_GetGlobalOption(FP_OPTION_MULTICLUSTER_QUERY_CLUSTERS));
        }
        else
            fprintf(stdout, "Multi-Cluster Failover Enabled:\t\t\t%s\n", "false");
    }

    /* Retrieve TCP/IP connection timeout in milliseconds */
    value = FPPool_GetIntOption(poolRef,FP_OPTION_TIMEOUT);
    errorDetected = checkAndPrintError("Get Connection Timeout Error: ");
    if (!errorDetected)
        fprintf(stdout, "Connection Timeout (ms):\t\t\t%d\n", (int) value);

    /* Retrieve the size of internal buffer size in bytes */
    value = FPPool_GetIntOption(poolRef,FP_OPTION_BUFFERSIZE);
    errorDetected = checkAndPrintError("Get Internal Buffer Size Error: ");
    if(!errorDetected)
        fprintf(stdout, "Internal Buffer Size (bytes):\t\t\t%d\n", (int) value);


    /* Retrieve the size of the prefetch buffer size in bytes */
    value = FPPool_GetIntOption(poolRef, FP_OPTION_PREFETCH_SIZE);
    errorDetected = checkAndPrintError("Get Prefetch Buffer Size Error: ");
    if(!errorDetected)
        fprintf(stdout, "Prefetch Buffer Size (bytes):\t\t\t%d\n", (int) value);

    /*  Retrieve the current cluster time */
    value = BUFSIZE;

    FPPool_GetClusterTime(poolRef, buffer, &value);
    errorDetected = checkAndPrintError("Get Cluster Time Error: ");
    if (!errorDetected)
        fprintf(stdout, "Cluster Time:\t\t\t\t\t%s\n", buffer);

    /* Retrieve the version number of FPLibrary.dll */
    FPPool_GetComponentVersion(FP_VERSION_FPLIBRARY_DLL, buffer, &value);
    errorDetected = checkAndPrintError("Get FP Library DLL Version Error: ");
    if (!errorDetected)
        fprintf(stdout, "FP Library DLL Version:\t\t\t\t%s\n", buffer);
}

/*
 * Retrieve the capability information of the Pool. The Pool capabilities are read-only
 * and can be set at the cluster as a sys-admin.
 */
void retrieveCapabilityInfo(const FPPoolRef poolRef)
{
    int errorDetected = 0;
    char buf[BUFSIZE];
    char fmtbuf[BUFSIZE];
    FPInt len;
    FPInt bufSize = BUFSIZE;
    FPRetentionClassContextRef classContextRef;

    fprintf(stdout,"\nThe Pool Capabilities\n");
    fprintf(stdout, "=====================\n");

    /*
     * Retrieve the read capability
     */
    FPPool_GetCapability(poolRef, FP_READ, FP_ALLOWED, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Read Capability Error: ");
    if (!errorDetected && sizeMatch(buf, bufSize))
        fprintf(stdout, "Read Operation Allowed:\t\t\t\t%s\n", buf);

    /* Retrieve the write capability */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_WRITE, FP_ALLOWED, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Write Capability Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "Write Operation Allowed:\t\t\t%s\n", buf);

    /* Retrieve the delete capability */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_DELETE, FP_ALLOWED, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Delete Capability Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "Delete Operation Allowed:\t\t\t%s\n", buf);

    /* Retrieve the purge capability */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_PURGE, FP_ALLOWED, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Purge Capability Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "Purge Operation Allowed:\t\t\t%s\n", buf);

    /* Retrieve the detection capability */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_EXIST, FP_ALLOWED, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Detection Capability Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "Detection Operation Allowed:\t\t\t%s\n", buf);

    /* Retrieve the C-Clip numeration operation(query) capability. */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_CLIPENUMERATION, FP_ALLOWED, buf, &bufSize);
    errorDetected = checkAndPrintError("Get C-Clip Enumeration Capability Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "C-Clip Enumeration(Query) Operation Allowed:\t%s\n", buf);

    /* Retrieve the default retention period. If the CDF does not specify a retention
     * period, then this value is used. 0 on a Basic Compliance model, -1 on a Compliance
     * Plus model
     */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_RETENTION, FP_DEFAULT, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Default Retention Period Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "The Default Retention Period:\t\t\t%s\n", buf);

    /* Get the RetentionClasses configured on the system */
    classContextRef = FPPool_GetRetentionClassContext(poolRef);

    if (classContextRef != (FPRetentionClassContextRef)NULL)
    {
        errorDetected = checkAndPrintError("Get RetentionClass Context Error: ");
    }

    if (!errorDetected)
    {
        FPRetentionClassRef classRef = 0;
        char className[BUFSIZE];

        if (classContextRef != (FPRetentionClassContextRef)NULL)
        {
            fprintf(stdout, "Valid Retention Classes configured:\n\n");

            classRef = FPRetentionClassContext_GetFirstClass(classContextRef);
            len = BUFSIZE;

            while (classRef)
            {
                len = BUFSIZE;
                FPRetentionClass_GetName(classRef, className, &len);
                sprintf(fmtbuf, "\t\t%s\t\t\t%s seconds\n",
                        className, L64D);
                fprintf(stdout, fmtbuf, FPRetentionClass_GetPeriod(classRef));
                classRef = FPRetentionClassContext_GetNextClass(classContextRef);
            }
        }
        else
        {
            fprintf(stdout, "Retention classes configured:\t\t\tfalse.\n");
        }
    }


    /* Retrieves the blob naming scheme */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_BLOBNAMING, FP_SUPPORTED_SCHEMES, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Blob Naming Scheme Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "\nThe Blob Naming Scheme:\t\t\t\t%s\n", buf);


    /* Is monitoring supported? */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_MONITOR, FP_ALLOWED, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Monitor Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "Monitoring Allowed:\t\t\t\t%s\n", buf);

    /* Are deletions logged on the server? */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_DELETIONLOGGING, FP_SUPPORTED, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Deletion Logging Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "Deletion Logged On Server:\t\t\t%s\n", buf);

    /* Can we do a privileged delete? */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_PRIVILEGEDDELETE, FP_ALLOWED, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Privileged Delete Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "Privileged Delete Allowed:\t\t\t%s\n", buf);

    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef,FP_COMPLIANCE, FP_EVENT_BASED_RETENTION, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Event Based Retention Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
        fprintf(stdout, "Event Based Retention:\t\t\t\t%s\n", buf);


    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef,FP_COMPLIANCE, FP_RETENTION_MIN_MAX, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Min/Max Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
    {
        fprintf(stdout, "Variable Min/Max:\t\t\t\t%s\n", buf);
        if (0==strcmp(FP_SUPPORTED,buf))
        {
            bufSize = BUFSIZE;
            FPPool_GetCapability(poolRef,FP_RETENTION, FP_VARIABLE_RETENTION_MIN, buf, &bufSize);
            errorDetected = checkAndPrintError("Get Min Variable Retention Value Error: ");
            if (!errorDetected&&sizeMatch(buf, bufSize))
                fprintf(stdout, "Min Variable Retention Value:\t\t\t%s\n", buf);

            bufSize = BUFSIZE;
            FPPool_GetCapability(poolRef,FP_RETENTION, FP_VARIABLE_RETENTION_MAX, buf, &bufSize);
            errorDetected = checkAndPrintError("Get Max Variable Retention Value Error: ");
            if (!errorDetected&&sizeMatch(buf, bufSize))
                fprintf(stdout, "Max Variable Retention Value:\t\t\t%s\n", buf);


            bufSize = BUFSIZE;
            FPPool_GetCapability(poolRef,FP_RETENTION, FP_FIXED_RETENTION_MIN, buf, &bufSize);
            errorDetected = checkAndPrintError("Get Min FIXED Retention Value Error: ");
            if (!errorDetected&&sizeMatch(buf, bufSize))
                fprintf(stdout, "Min FIXED Retention Value:\t\t\t%s\n", buf);

            bufSize = BUFSIZE;
            FPPool_GetCapability(poolRef,FP_RETENTION, FP_FIXED_RETENTION_MAX, buf, &bufSize);
            errorDetected = checkAndPrintError("Get Max FIXED Retention Value Error: ");
            if (!errorDetected&&sizeMatch(buf, bufSize))
                fprintf(stdout, "Max FIXED Retention Value:\t\t\t%s\n", buf);

            bufSize = BUFSIZE;
            FPPool_GetCapability(poolRef,FP_RETENTION, FP_RETENTION_DEFAULT, buf, &bufSize);
            errorDetected = checkAndPrintError("Get Retention Default Value Error: ");
            if (!errorDetected&&sizeMatch(buf, bufSize))
                fprintf(stdout, "Retention Default Value:\t\t\t%s\n", buf);
            

        }
    }

    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef,FP_COMPLIANCE, FP_RETENTION_HOLD, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Retention Hold Supported Error: ");
    if (!errorDetected&&sizeMatch(buf, bufSize))
    {
        fprintf(stdout, "Retention Hold Supported:\t\t\t%s\n", buf);
        if (0==strcmp(FP_SUPPORTED,buf))
        {
            bufSize = BUFSIZE;
            FPPool_GetCapability(poolRef,FP_RETENTION_HOLD, FP_ALLOWED, buf, &bufSize);
            errorDetected = checkAndPrintError("Get Retention Hold Supported Error: ");
            if (!errorDetected&& sizeMatch(buf, bufSize))
                fprintf(stdout, "Retention Hold Allowed:\t\t\t\t%s\n", buf);
        }
    }

    /* Show profiles for current pool connection */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_POOL_POOLMAPPINGS, FP_PROFILES, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Pool Profiles Error: ");
    if (!errorDetected && sizeMatch(buf, bufSize))
        fprintf(stdout, "FPPool Profile Access:\t\t\t%s\n", buf);

    /* Show pool mappings for current pool connection */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_POOL_POOLMAPPINGS, FP_POOLS, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Pool Mappings Error: ");
    if (!errorDetected && sizeMatch(buf, bufSize))
        fprintf(stdout, "FPPool Pool Mappings:\t\t\t%s\n", buf);

    /* Show cluster compliance mode */
    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef, FP_COMPLIANCE, FP_MODE, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Compliance Mode Error: ");
    if (!errorDetected && sizeMatch(buf, bufSize))
        fprintf(stdout, "Cluster Compliance Mode:\t\t\t%s\n", buf);
}


char **inputData(const char *header,
                 const int  numParameters,
                 const char *prompts[],
                 const char *validOptions[],
                 const char *defaults[])
{
    int i;
    char buffer[BUFSIZE];
    char **values = (char **) malloc(numParameters * sizeof(char *));

    fprintf(stderr, "Enter values or leave blank to use defaults:\n\n");

    i = 0;
    while (i < numParameters)
    {
        FPBool valid = false;

        if (*prompts[i] !=  '\0')
            fprintf(stderr, "%s: ", prompts[i]);

        if (*validOptions[i] != '\0')
            fprintf(stderr, " Valid options [%s] ", validOptions[i]);

        if (*defaults[i] != '\0')
            fprintf(stderr, " <%s> ", defaults[i]);

        fgets(buffer, sizeof(buffer), stdin);
        buffer[strlen(buffer) - 1] = '\0';  /* Remove the terminating \n */

        if (buffer[0] == '\0')
        {
            if (*defaults[i] != '\0') /* Accept the default */
            {
                values[i] = (char *) malloc((strlen(defaults[i])+1) * sizeof(char));
                strcpy(values[i], defaults[i]);
                valid = true;
            }
            else
            {
                fprintf(stdout, "There is no default value - please enter data\n");
            }
        }
        else
        {
            /* Test that data is valid */
            if (*validOptions[i] == '\0') /* No choices to validate so accept what user entered */
            {
                values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                strcpy(values[i], buffer);
                valid = true;
            }
            else
            {
                const char *substr = (const char *) strstr((char *) validOptions[i], buffer);

                if (substr) /* Input is within the validOptions string - check the if it is the whole value */
                {
                    const char *optionEnd =  strchr(substr, '|');

                    if (optionEnd)
                    {
                        int length = (int) (optionEnd - substr);

                        if (length == (int) strlen(buffer))
                            valid = true;
                    }
                    else
                        valid = true;
                }


                if (!valid)
                    fprintf(stderr, "%s is not in valid choices: [%s]\n", buffer, validOptions[i]);
                else
                {
                    values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                    strcpy(values[i], buffer);
                }
            }
        }
        if (valid)
            ++i;
    }

    return values;
}

FPInt checkAndPrintError(const char *errorMessage)
{
    /* Get the error code of the last SDK API function call */
    FPInt errorCode = FPPool_GetLastError();
    if (errorCode != ENOERR)
    {
        FPErrorInfo errInfo;
        fprintf(stderr, errorMessage);
        /* Get the error message of the last SDK API function call */
        FPPool_GetLastErrorInfo(&errInfo);
        if (!errInfo.message) /* the human readable error message */
            fprintf(stderr, "%s\n", errInfo.errorString);
        else if (!errInfo.errorString) /* the error string corresponds to an error code */
            fprintf(stderr, "%s\n", errInfo.message);
        else
            fprintf(stderr, "%s%s%s\n",errInfo.errorString," - ",errInfo.message);
    }

    return errorCode;
}

