/******************************************************************************\
 *
 * Copyright (c) 2001-2006 EMC Corporation
 * All Rights Reserved
 *
 * GenericStreamRead.c
 *
 * GenericStreamRead Source File Build Version @version.full@
 *
 * This sourcefile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/

/*
 * Example - Using The Centera Access API To Read From A Generic Stream.
 *
 * This example shows how to use the callback functions to create a generic stream for
 * reading the data out of Centera.
 * The IP address(es) of the access node(s) to the cluster and the content address of the
 * C-Clip are entered via the command line.
 * The content of all the tags in the C-Clip is retrieved and saved to a single file.
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <FPAPI.h>
#include <malloc.h>

typedef struct {
    FILE *fileHandler;
}StreamUserData;

#define FILE_WRITE_ERROR -1
#define MAX_NAME_SIZE (128+1)
#define BUFSIZE (128 + 1)

char **inputData(const char *, const int, const char *[], const char *[], const char *[]);
FPInt checkAndPrintError(const char *);

static long out_complete_callback(FPStreamInfo *);

int main(int argc, char* argv[])
{
    FPClipID clipID;
    FPPoolRef poolRef;
    FPClipRef clipRef;
    FPInt retCode = 0;
    int index;
    const char *appVersion="3.1";
    const char *poolAddress = NULL;
    const char *appName = "Generic Stream Read";
    const int numParameters = 2;
    const char *prompts[] = { "Enter the IP address or DNS name of the cluster(s)",
                              "Enter the Content Address of the clip to be read "};
    const char *choices[] = { "" , "" };
    const char *defaults[] = { "us1cas1.centera.org,us1cas2.centera.org", "" };

    /* Verify the input options */
    char **values = inputData(appName, numParameters, prompts, choices, defaults);
    poolAddress = values[0];
    strcpy(clipID, values[1]);


    /*Stores your application's name and version for registration on Centera
    This call should be made one time, before the FPPoolOpen() call,
    for each application that interfaces with centera
    *
    Applications can also be registered via the environment variables 
    FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
    will override what is set through environment variable.
    */
    FPPool_RegisterApplication(appName,appVersion);
    retCode = checkAndPrintError("Application Registration Error: ");

    /* New in 2.3 - use LazyOpen option for opening pools as it is more efficient */
    FPPool_SetGlobalOption(FP_OPTION_OPENSTRATEGY, FP_LAZY_OPEN);

    (void) argc; (void) argv; /* avoid 'unused' warnings */
    
    /*
     * Open up a Pool
     */
    poolRef = FPPool_Open(poolAddress);

    retCode = checkAndPrintError("Pool Open Error: ");
    /* Read the content of the blobs of the C-Clip to a file */
    if (!retCode)
    {
        FPStreamRef genericStream = 0;
        FILE* fileStream = NULL;

        /*
         * Open the C-Clip and read the C-Clip to the memory
         */
        clipRef = FPClip_Open(poolRef, clipID, FP_OPEN_FLAT);
        retCode = checkAndPrintError("C-Clip Open Error: ");
        if (!retCode)
        {
            /* Create the file for output,which will be named as clipID.blobout */
            char fileName[MAX_NAME_SIZE];
            sprintf(fileName, "%s.blobout", clipID);

            fileStream = fopen(fileName, "wb");
            if (fileStream)
            {
                /* Create a generic stream for output */
                StreamUserData *userData = (StreamUserData *)calloc(1, sizeof(StreamUserData));
                if (userData)
                {
                    userData->fileHandler = (FILE *)fileStream;
                    /* Create the Generic Stream for reading the blob data. Where we use the default SDK implemented              
                     * callbacks, a null pointer (rather than a pointer to our function implementation)
                     * is supplied. We process the returned data using the Complete callback.
                     */
                    genericStream = FPStream_CreateGenericStream((const FPStreamProc) 0,            /* Prepare Buffer */
                                                                 out_complete_callback, /* Complete */
                                                                 (const FPStreamProc) 0,            /* Set Mark */
                                                                 (const FPStreamProc) 0,            /* Reset Mark */
                                                                 (const FPStreamProc) 0,            /* Close */
                                                                 userData);
                }
                /* Initial settings for the output stream */
                if (genericStream != 0 )
                {
                    FPStreamInfo *streamInfo = FPStream_GetInfo(genericStream);
                    if ( streamInfo != NULL )
                        streamInfo->mReadFlag = false; /* Set the read flag to false */
                    else
                    {
                        FPStream_Close(genericStream);
                        genericStream = 0;
                    }
                }

                retCode = checkAndPrintError("Input Generic Stream Create Error: ");
                if (!retCode)
                {
                    /* Read the content of the Blobs to the generic stream */
                    Boolean moreTags = true;
                    FPInt retCode = 0;
                    while (moreTags && !retCode)
                    {
                        /* Retrieve the next tag
                         */
                        FPTagRef tag = FPClip_FetchNext(clipRef);
                        retCode = checkAndPrintError("Get Tag Error: ");
                        if (!tag || retCode)
                            moreTags = false;
                        else
                        {
                            /*
                             * Read out the blob data into the generic stream
                             */
                            FPTag_BlobRead(tag, genericStream, FP_OPTION_DEFAULT_OPTIONS);
                            retCode = checkAndPrintError("Blob Read Error: ");

                            if (!retCode)
                                fprintf(stdout, "The C-Clip has been stored to %s\n", fileName);
                        }

                        /*
                         * Close the tag
                         */
                        FPTag_Close(tag);
                        retCode = checkAndPrintError("Close Tag Error: ");
                    }

                    FPStream_Close(genericStream);
                    retCode = checkAndPrintError("Close Stream Error: ");
                }
                fclose(fileStream);
            }
            else
            {
                fprintf(stderr, "Can Not Create The File For Output. \n");
                retCode = FILE_WRITE_ERROR;
            }
            /*
             * Close the C-Clip
             */
            FPClip_Close(clipRef);
            retCode = checkAndPrintError("Close Clip Error: ");
        }
    }

    /*
     * Close the pool
     */
    FPPool_Close(poolRef);
    retCode = checkAndPrintError("Pool Close Error: ");

    fprintf(stdout, "Press <enter> to continue.\n");
    (void) getchar();

    for (index=0;index<numParameters; index++)
    {
         free(values[index]);
    }
    free(values);

    return retCode;
}


/*******************************************************************************
 ***     output stream callback functions
 *****************************************************************************/

/*
 * Called before the data is written to a buffer. If you allow the SDK to manage the buffer
 * then in most cases it is not necessary to implement this function for output streams, so we
 * leave it unimplemented and set to NULL in the creation of the stream.
 *
 * static long out_prepare_buffer_callback (FPStreamInfo *streamInfo)
 *
 */

/*
 * Put the data into mBuffer in the FPStreamInfo so that it can be written
 * to the file stream. The generic stream calls this method when the buffer that has
 * been prepared with the prepareBufferProc is no longer needed. In case of the output
 * stream, it means that the buffer contains the requested data and that it can be written
 * to an output device
 */
static long out_complete_callback (FPStreamInfo *streamInfo)
{
    long retCode = ENOERR;
    StreamUserData *userData = (StreamUserData *)streamInfo->mUserData;

    /* Check for a successful completion */
    if (streamInfo->mAtEOF && (0 == streamInfo->mTransferLen))
    {
        fprintf(stderr, "Successfully transferred %ld bytes.\n", (long int)streamInfo->mStreamPos);
        return ENOERR;
    }

    if (userData!= NULL)
    {
        FILE *fileHandler = (FILE *)(userData->fileHandler);
        unsigned int sz = (unsigned int)streamInfo->mTransferLen;
        const char *buf = (char *)streamInfo->mBuffer;

        /* Read data from the generic stream's mBuffer into the file stream */
        unsigned int numWrite = (unsigned int) fwrite(buf, sizeof(char), sz, fileHandler);
        if (numWrite < sz)
            retCode = FILE_WRITE_ERROR;

        /* Update the buffer and transfer the data */
        streamInfo->mStreamPos      +=  numWrite;
        streamInfo->mTransferLen    = numWrite;
    }

    return retCode;
}

/*
 * Called when the transfer has completed. In most cases, it is not necessary to implement this
 * function for output streams if you allow the SDK to manage the buffer so we
 * leave it unimplemented and set to NULL in the creation of the stream.
 *
 * static long close_callback (FPStreamInfo *streamInfo)
 *
 */

/*
 * This callback should be left unimplemented (and passed in as NULL
 * in the call to FPStream_CreateGenericStream) as from 3.1 onwards
 * the SDK provides the marker support. 
 *
 * static long out_set_mark_callback(FPStreamInfo *streamInfo)
 *
 */

/*
 * This callback should be left unimplemented (and passed in as NULL
 * in the call to FPStream_CreateGenericStream) as from 3.1 onwards
 * the SDK provides the rewind capability. 
 *
 * static long out_reset_mark_callback(FPStreamInfo *streamInfo)
 *
 */


/*
 *
 * User input processing
 *
 */
char **inputData(const char *header,
                 const int numParameters,
                 const char *prompts[],
                 const char *validOptions[],
                 const char *defaults[])
{
    int i;
    char buffer[BUFSIZE];
    char **values = (char **) malloc(numParameters * sizeof(char *));

    (void) header; /* just to avoid 'unused' warning */

    fprintf(stderr, "Enter values or leave blank to use defaults:\n\n");

    i = 0;
    while (i < numParameters)
    {
        FPBool valid = false;

        if (*prompts[i] !=  '\0')
            fprintf(stderr, "%s: ", prompts[i]);

        if (*validOptions[i] != '\0')
            fprintf(stderr, " Valid options [%s] ", validOptions[i]);

        if (*defaults[i] != '\0')
            fprintf(stderr, " <%s> ", defaults[i]);

        fgets(buffer, sizeof(buffer), stdin);
        buffer[strlen(buffer) - 1] = '\0';  /* Remove the terminating \n */

        if (buffer[0] == '\0')
        {
            if (*defaults[i] != '\0') /* Accept the default */
            {
                values[i] = (char *) malloc((strlen(defaults[i])+1) * sizeof(char));
                strcpy(values[i], defaults[i]);
                valid = true;
            }
            else
            {
                fprintf(stdout, "There is no default value - please enter data\n");
            }
        }
        else
        {
            /* Test that data is valid */
            if (*validOptions[i] == '\0') /* No choices to validate so accept what user entered */
            {
                values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                strcpy(values[i], buffer);
                valid = true;
            }
            else
            {
                const char *substr = (const char *) strstr((char *) validOptions[i], buffer);

                if (substr) /* Input is within the validOptions string - check the if it is the whole value */
                {
                    const char *optionEnd =  strchr(substr, '|');

                    if (optionEnd)
                    {
                        int length = (int) (optionEnd - substr);

                        if (length == (int) strlen(buffer))
                            valid = true;
                    }
                    else
                        valid = true;
                }


                if (!valid)
                    fprintf(stderr, "%s is not in valid choices: [%s]\n", buffer, validOptions[i]);
                else
                {
                    values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                    strcpy(values[i], buffer);
                }
            }
        }
        if (valid)
            ++i;
    }

    return values;
}

FPInt checkAndPrintError(const char *errorMessage)
{
    /* Get the error code of the last SDK API function call */
    FPInt errorCode = FPPool_GetLastError();
    if (errorCode != ENOERR)
    {
        FPErrorInfo errInfo;
        fprintf(stderr, errorMessage);
        /* Get the error message of the last SDK API function call */
        FPPool_GetLastErrorInfo(&errInfo);
        if (!errInfo.message) /* the human readable error message */
            fprintf(stderr, "%s\n", errInfo.errorString);
        else if (!errInfo.errorString) /* the error string corresponds to an error code */
            fprintf(stderr, "%s\n", errInfo.message);
        else
            fprintf(stderr, "%s%s%s\n",errInfo.errorString," - ",errInfo.message);
    }

    return errorCode;
}
