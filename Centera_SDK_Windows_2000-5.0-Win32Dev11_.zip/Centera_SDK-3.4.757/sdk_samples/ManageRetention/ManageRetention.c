/******************************************************************************\
 *
 * Copyright (c) 2001-2006 EMC Corporation
 * All Rights Reserved
 *
 * ManageRetention.c
 *
 * ManageRetention Source File Build Version @version.full@
 *
 * This sourcefile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
 * This example demonstrated how to manage the Retention Period of a clip. It
 * also demonstrates the new 2.3 SDK Retention Classes feature.
 *
\******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <malloc.h>

/*
 * The standard header file for the Centera access API.
 * This includes all function prototypes and type
 * definitions needed to use the access API.
 */
#include <FPAPI.h>

/* 64-bit printf formats */
#if defined(_MSC_VER)   /* Visual C++ */
#  define L64D "%I64d"
#else
#  define L64D "%lld"
#endif


#define BUFSIZE (128 + 1)
#define TIMESIZE 256

char **inputData(const char *, const int, const char *[], const char *[], const char *[]);
FPInt checkAndPrintError(const char *);
FPRetentionClassRef getNewRetentionData(const FPPoolRef, const FPRetentionClassContextRef, FPLong*);
int printRetentionInfo(const FPPoolRef, const FPClipRef);

int main(int argc, char *argv[])
{
    const char *poolAddress = 0;
    FPClipID clipID;
    FPPoolRef poolRef;
    FPInt retCode = 0;
    int index;
    const char *appVersion="3.1";
    char fmtbuf[BUFSIZE];

    const char *appName = "Manage Retention";
    const int numParameters = 2;
    const char *prompts[] = { "Enter the IP address or DNS name of the cluster(s)",
                              "Enter the Content Address of the object to be retrieved " };
    const char *choices[] = { "" , "" };
    const char *defaults[] = { "us1cas1.centera.org,us1cas2.centera.org" , "" };

    /* Verify the input options */
    char **values = inputData(appName, numParameters, prompts, choices, defaults);
    poolAddress = values[0];
    strcpy(clipID, values[1]);


    /*Stores your application's name and version for registration on Centera
    This call should be made one time, before the FPPoolOpen() call,
    for each application that interfaces with centera
    *
    Applications can also be registered via the environment variables 
    FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
    will override what is set through environment variable.
    */
    FPPool_RegisterApplication(appName,appVersion);
    retCode = checkAndPrintError("Application Registration Error: ");

    /*
     * Open up a Pool
     */

    /* New in 2.3 - use LazyOpen option for opening pools as it is more efficient */
    FPPool_SetGlobalOption(FP_OPTION_OPENSTRATEGY, FP_LAZY_OPEN);

    poolRef = FPPool_Open(poolAddress);
    retCode = checkAndPrintError("Pool Open Error: ");
    if (!retCode)
    {
        FPClipRef clipRef = FPClip_Open(poolRef, clipID, FP_OPEN_ASTREE);
        retCode = checkAndPrintError("C-Clip Open Error: ");

        if (!retCode)
        {
            FPRetentionClassContextRef classContextRef;
            printRetentionInfo(poolRef, clipRef);

            classContextRef = FPPool_GetRetentionClassContext(poolRef);
            if (classContextRef != (FPRetentionClassContextRef) NULL)
            {
                retCode = checkAndPrintError("Get RetentionClass Context Error: ");
            }

            if (!retCode)
            {
                FPRetentionClassRef classRef = 0;
                char className[BUFSIZE];
                FPLong retentionSecs = 0;

                /* Print out a list of known retention class names and their values */
                if (classContextRef != (FPRetentionClassRef) NULL)
                {
                    FPInt len = BUFSIZE;

                    fprintf(stdout, "Valid Retention Classes on %s are:\n\n", poolAddress);

                    classRef = FPRetentionClassContext_GetFirstClass(classContextRef);

                    while (classRef && !retCode)
                    {
                        len = BUFSIZE;
                        FPRetentionClass_GetName(classRef, className, &len);
                        retCode = checkAndPrintError("Close RetentionClass Error: ");

                        sprintf(fmtbuf, "\tClass %%s\t has an interval of %s seconds\n", L64D);
                        fprintf(stdout, fmtbuf, className, FPRetentionClass_GetPeriod(classRef));

                        FPRetentionClass_Close(classRef);
                        retCode |= checkAndPrintError("Close RetentionClass Error: ");

                        classRef = FPRetentionClassContext_GetNextClass(classContextRef);
                        retCode |= checkAndPrintError("Close RetentionClass Error: ");
                    }
                }
                else
                {
                    fprintf(stdout, "Retention classes are not supported on %s.\n", poolAddress);
                }

                /* Get the retention class name or period from the user */
                classRef = getNewRetentionData(poolRef, classContextRef, &retentionSecs);

                if (classRef != (FPRetentionClassRef) NULL)
                {
                    /* User entered a valid RetentionClass name */
                    FPClip_SetRetentionClass(clipRef, classRef);
                    retCode = checkAndPrintError("Set Retention Class Error: ");

                    /* Free up the classRef resources */
                    FPRetentionClass_Close(classRef);
                    retCode = checkAndPrintError("Close RetentionClass Error: ");
                }
                else
                {
                    /* User entered a raw numeric value */
                    FPClip_SetRetentionPeriod(clipRef,retentionSecs);
                    retCode = checkAndPrintError("Set RetentionPeriod Error: ");
                }

                if (classContextRef != (FPRetentionClassContextRef) NULL)
                {
                    FPRetentionClassContext_Close(classContextRef);
                    retCode = checkAndPrintError("Close RetentionClassContextSet Error: ");
                }

                if (!retCode)
                {
                    FPClipID newClipID;
                    FPClip_Write(clipRef, newClipID);
                    retCode = checkAndPrintError("C-Clip Write Error: ");
                    if (!retCode)
                    {
                        fprintf(stdout, "The content address of the new C-Clip: %s\n", newClipID);
                        retCode = printRetentionInfo(poolRef, clipRef);
                    }
                }
            }
            FPClip_Close(clipRef);
            retCode = checkAndPrintError("C-Clip Close Error: ");
            /* Delete the old C-Clip */
            FPClip_Delete(poolRef, clipID);
            retCode = checkAndPrintError("The old C-Clip Delete Error: ");
        }
        FPPool_Close(poolRef);
        retCode = checkAndPrintError("Pool Close Error: ");
    }

    for (index=0;index<numParameters; index++)
    {
         free(values[index]);
    }
    free(values);

    return retCode;
}

/*
 * Print out the creation time and the retention period of the C-Clip
 */
int printRetentionInfo(const FPPoolRef poolRef, const FPClipRef clipRef)
{
    FPInt   creationTimeSize = TIMESIZE;
    char    creationTimeBuffer[TIMESIZE];
    int     errorDetected = 0;
    char    fmtbuf[BUFSIZE];

    /*
     * Get the creation date of the C-Clip
     */
    FPClip_GetCreationDate(clipRef, creationTimeBuffer, &creationTimeSize);
    errorDetected = checkAndPrintError("Get C-Clip Creation Date Error: ");
    if (!errorDetected)
    {
        /*
         * Get the retention period of the C-Clip.
         *
         *      For an existing CDF with a Period, if you edit the C-Clip and set
         *      a Class, the Period is removed when you write the C-Clip.
         *
         *      The reverse is also true i.e. for an existing CDF with a Class,
         *      if you edit the C-Clip and set the Period, the Class is removed.
         *
         */
        FPLong retentionTime = FPClip_GetRetentionPeriod(clipRef);
        errorDetected = checkAndPrintError("Get C-Clip Retention Period Error: ");

        if (!errorDetected)
        {
            char className[BUFSIZE];
            FPInt l = BUFSIZE;

            FPClip_GetRetentionClassName (clipRef, className, &l);
            errorDetected = checkAndPrintError("Get C-Clip Retention Class Name Error: ");

            if (!errorDetected)
            {

                fprintf(stdout, "The C-Clip was created at %s, ", creationTimeBuffer);
                if (className[0] != '\0')
                {
                    fprintf(stdout, "with a Retention Class of %s.\n", className);
                }
                else
                {
                    fprintf(stdout, "with no Retention Class.\n");
                }

                if (retentionTime == FP_DEFAULT_RETENTION_PERIOD)
                {
                    /* Need to get the default value for retention on the cluster */
                    char value[64];
                    FPInt valueLen = 64;

                    fprintf(stdout, "The default Retention of the Cluster is used - ");
                    FPPool_GetCapability(poolRef, FP_RETENTION, FP_DEFAULT, value, &valueLen);
                    retentionTime = atol(value);
                }
                else
                {
                    fprintf(stdout, "The clip has it's own Retention Period - ");
                }

                switch ((int) retentionTime)
                {
                case FP_NO_RETENTION_PERIOD:
                    fprintf(stdout, "no Retention.");
                    break;
                case FP_INFINITE_RETENTION_PERIOD:
                    fprintf(stdout, "Infinite Retention.");
                    break;
                default:
                    sprintf(fmtbuf," %s seconds.", L64D);
                    fprintf(stdout, fmtbuf, retentionTime);
                }

                fprintf(stdout, "\n");
            }
        }
    }

    return errorDetected;
}


FPRetentionClassRef getNewRetentionData(const FPPoolRef poolRef, const FPRetentionClassContextRef classContextRef, FPLong *retentionSecs)
{
    int validPeriod = false;
    int validClass = false;
    long minimumRetention = 0;
    long maximumRetention = -1;
    int errorDetected = 0;

    char retentionStr[BUFSIZE];
    char *cPtr = NULL;
    char buf[BUFSIZE];
    FPInt bufSize = BUFSIZE;
    FPRetentionClassRef classRef = (FPRetentionClassRef) NULL;

    /* Get the value of any Minimum / Maximum Governor that may be configured */
    FPPool_GetCapability(poolRef,FP_COMPLIANCE, FP_RETENTION_MIN_MAX, buf, &bufSize);
    errorDetected = checkAndPrintError("Get Min/Max Error: ");
    if (!errorDetected && (0==strcmp(FP_SUPPORTED,buf)))
    {
        bufSize = BUFSIZE;
        FPPool_GetCapability(poolRef,FP_RETENTION, FP_FIXED_RETENTION_MIN, buf, &bufSize);
        errorDetected = checkAndPrintError("Get Min FIXED Retention Value Error: ");

        if (!errorDetected)
        {
            minimumRetention = atol(buf);
            fprintf(stdout, "Minimum Retention: %s seconds, ", buf);

            bufSize = BUFSIZE;
            FPPool_GetCapability(poolRef,FP_RETENTION, FP_FIXED_RETENTION_MAX, buf, &bufSize);
            errorDetected = checkAndPrintError("Get Max FIXED Retention Value Error: ");

            if (!errorDetected)
            {
                maximumRetention = atol(buf);
                
                if (maximumRetention > 0)
                    fprintf(stdout, "Maximum Retention: %s seconds\n", buf);
                else
                    fprintf(stdout, "Maximum Retention: infinite\n");
            }
        }
    }


    do
    {
        fprintf(stdout, "\nEnter the new retention class name (or period in seconds): ");
        gets(retentionStr);

        /* Verify the input options - find the first non-numeric character (if any) in the string */
        cPtr = retentionStr;

        /* Allow negation as -1 or -2 is a valid option */
        if (*cPtr == '-')
            ++cPtr;

        while (isdigit(*cPtr) && *cPtr != '\0')
        {
            ++cPtr;
        }

        if (*cPtr)
        {
            /* Not all characters are digits so we have a RetentionClass string */
            if (classContextRef == (FPRetentionClassRef) NULL)
                fprintf(stderr, "Retention classes are not supported.\n");
            else
            {
                /* Check for existence of Retention Class with this name */
                classRef = FPRetentionClassContext_GetNamedClass(classContextRef, retentionStr);

                if (!checkAndPrintError("Get Named Class Error: "))
                {
                    if (classRef != (FPRetentionClassRef) NULL)            
                        validClass = true;
                    else
                        fprintf(stderr, "%s is not a valid Retention Class name.\n\n", retentionStr);
                }
            }
        }
        else
        {
            if (strlen(retentionStr) > 0)
            {
                /* Period has been supplied in seconds */
                *retentionSecs = atol(retentionStr);

                if (*retentionSecs >= minimumRetention)
                {
                    if (maximumRetention < 0 || *retentionSecs <= maximumRetention) 
                        validPeriod = true;
                    else
                        fprintf(stderr, "Maximum retention must be <= %ld\n", maximumRetention);
                }
                else
                    fprintf(stderr, "Minimum retention must be >= %ld\n", minimumRetention);
            }
        }


    } while (!validPeriod && !validClass);

    return classRef;
}

char **inputData(const char *header,
                 const int  numParameters,
                 const char *prompts[],
                 const char *validOptions[],
                 const char *defaults[])
{
    int i;
    char buffer[BUFSIZE];
    char **values = (char **) malloc(numParameters * sizeof(char *));

    fprintf(stderr, "Enter values or leave blank to use defaults:\n\n");

    i = 0;
    while (i < numParameters)
    {
        FPBool valid = false;

        if (*prompts[i] !=  '\0')
            fprintf(stderr, "%s: ", prompts[i]);

        if (*validOptions[i] != '\0')
            fprintf(stderr, " Valid options [%s] ", validOptions[i]);

        if (*defaults[i] != '\0')
            fprintf(stderr, " <%s> ", defaults[i]);

        fgets(buffer, sizeof(buffer), stdin);
        buffer[strlen(buffer) - 1] = '\0';  /* Remove the terminating \n */

        if (buffer[0] == '\0')
        {
            if (*defaults[i] != '\0') /* Accept the default */
            {
                values[i] = (char *) malloc((strlen(defaults[i])+1) * sizeof(char));
                strcpy(values[i], defaults[i]);
                valid = true;
            }
            else
            {
                fprintf(stdout, "There is no default value - please enter data\n");
            }
        }
        else
        {
            /* Test that data is valid */
            if (*validOptions[i] == '\0') /* No choices to validate so accept what user entered */
            {
                values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                strcpy(values[i], buffer);
                valid = true;
            }
            else
            {
                const char *substr = (const char *) strstr((char *) validOptions[i], buffer);

                if (substr) /* Input is within the validOptions string - check if it is the whole value */
                {
                    const char *optionEnd =  strchr(substr, '|');

                    if (optionEnd)
                    {
                        int length = (int) (optionEnd - substr);

                        if (length == (int) strlen(buffer))
                            valid = true;
                    }
                    else
                        valid = true;
                }


                if (!valid)
                    fprintf(stderr, "%s is not in valid choices: [%s]\n", buffer, validOptions[i]);
                else
                {
                    values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                    strcpy(values[i], buffer);
                }
            }
        }
        if (valid)
            ++i;
    }

    return values;
}

FPInt checkAndPrintError(const char *errorMessage)
{
    /* Get the error code of the last SDK API function call */
    FPInt errorCode = FPPool_GetLastError();
    if (errorCode != ENOERR)
    {
        FPErrorInfo errInfo;
        fprintf(stderr, errorMessage);
        /* Get the error message of the last SDK API function call */
        FPPool_GetLastErrorInfo(&errInfo);
        if (!errInfo.message) /* the human readable error message */
            fprintf(stderr, "%s\n", errInfo.errorString);
        else if (!errInfo.errorString) /* the error string corresponds to an error code */
            fprintf(stderr, "%s\n", errInfo.message);
        else
            fprintf(stderr, "%s%s%s\n",errInfo.errorString," - ",errInfo.message);
    }

    return errorCode;
}

