/******************************************************************************\
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * All Rights Reserved
 *
 * PAI_api.h
 *
 * PAI module Header File Build Version 3.4.107
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/
/******************************************************************************\
 *
 * The reference implementation of a Pool Access Information (PAI) module
 *
 * This file defines the interface for the C API
 *
 * DO NOT alter this file when implementing a PAI module!!!
 * 
\******************************************************************************/
#ifndef __PAI_API_H_
#define __PAI_API_H_

#include "PAI_module.h"

////////////////////////////////////////////////////////////////////////////////
// C API to the PAI class - SDK section
////////////////////////////////////////////////////////////////////////////////
extern "C" {

/**
 * PAI_Initialize - Get info associated with a poolname in the credential store
 *
 * @param a char pointer to the poolname
 * @param a pointer to a PAI ref to update on successful opening of the profile
 *
 * @returns PAI_AOK on success
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 * @returns PAI_NO_POOL if the profile cannot be found
 */
PAI_MODULE_API long
PAI_Initialize (char *inPoolName, PAIRef *outRef);

/**
 * PAI_GetVersion - retrieve the version of the PAI module
 *
 * @param a PAI ref (set by PAI_Initialize)
 * @param a char pointer to copy the version string into
 * @param an unsigned short or size_t, depending on the platform,
 *        pointer containing the max length of the version string on
 *        input, it is changed to contain the number of characters is the
 *        actual version string (including the terminating NULL character)
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 * @returns PAI_VERSION_OVERFLOW if the version buffer is too short
 */
PAI_MODULE_API long
PAI_GetVersion (PAIRef inRef, char *outVersion, PAI_UNSIGNED_SHORT *ioVersionLen);

/**
 * PAI_GetAddress - retrieve the address associated with the pool
 *
 * @param a PAI ref (set by PAI_Initialize)
 * @param a char pointer to copy the address string into
 * @param an unsigned short or size_t pointer, depending on the platform, containing
 *        the max length of the address string on input, it is changed to
 *        contain the number of characters is the actual address string 
 *        (including the terminating NULL character)
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 * @returns PAI_NO_ADDRESS if there is no address available
 * @returns PAI_ADDRESS_OVERFLOW if the address buffer is too short
 */
PAI_MODULE_API long
PAI_GetAddress (PAIRef inRef, char *outAddress, PAI_UNSIGNED_SHORT *ioAddressLen);

/**
 * PAI_GetUserName - retrieve access information
 *
 * @param a PAI ref (set by PAI_Initialize)
 * @param a char pointer indicating the type of section (currently,
 *        only sections of type "cluster" are supported)
 * @param a char pointer to the section name
 * @param a char pointer to copy the name string into
 * @param an unsigned short or size_t pointer, depending on the platform, 
 *        containing the max length of the name string on input, it is 
 *        changed to contain the number of characters is the
 *        actual name string (including the terminating NULL character)
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 * @returns PAI_BAD_CLUSTERID if the cluster ID is badly formed
 * @returns PAI_UNKNOWN_CLUSTERID if the cluster ID is not found
 * @returns PAI_PROFILE_OVERFLOW if the name buffer is too short
 * @returns PAI_SECRET_OVERFLOW if the secret buffer is too short
 * @returns PAI_USE_ANONYMOUS anonymous login is necessary
 */
PAI_MODULE_API long
PAI_GetUserName (PAIRef inRef,
				 char *inKeyType, char *inKey,
                 char *outUserName, PAI_UNSIGNED_SHORT *ioUserNameLen);

/**
 * PAI_GetCredential - retrieve access information
 *
 * @param a PAI ref (set by PAI_Initialize)
 * @param a char pointer indicating the type of section (currently,
 *        only sections of type "cluster" are supported)
 * @param a char pointer to the section name
 * @param a char pointer to the credential ID
 * @param a char pointer to copy the credential string into
 * @param an unsigned short or size_t pointer, depending on the platform, containing
 *        the max length of the credential string on input, it is 
 *        changed to contain the number of characters is the
 *        actual credential string (including the terminating NULL character)
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 * @returns PAI_BAD_CLUSTERID if the cluster ID is badly formed
 * @returns PAI_UNKNOWN_CLUSTERID if the cluster ID is not found
 * @returns PAI_PROFILE_OVERFLOW if the name buffer is too short
 * @returns PAI_SECRET_OVERFLOW if the secret buffer is too short
 * @returns PAI_USE_ANONYMOUS anonymous login is necessary
 */
PAI_MODULE_API long
PAI_GetCredential (PAIRef inRef,
				   char *inKeyType, char *inKey, 
				   char *inCredentialID,
                   char *outCredential, PAI_UNSIGNED_SHORT *ioCredentialLen);

/**
 * Parses the passed in connection string based on IP addresses. For example the following 
 * connection string: 
 *
 * Example 1:
 * "10.10.10.10?name=profA,secret=foo,11.11.11.11?path=c:\temp\auth.xml,12.12.12.12,13.13.13.13"
 *
 * will be parsed, and the resulting elements will be put into the outConnectionStrings 
 * array as follows:
 * outConnectionStrings[0] = 10.10.10.10?name=profA,secret=foo
 * outConnectionStrings[1] = 11.11.11.11?path=c:\temp\auth.xml
 * outConnectionStrings[2] = 12.12.12.12
 * outConnectionStrings[3] = 13.13.13.13
 *
 * This next example shows another scenario:
 *
 * Example 2:
 * "10.10.10.10,11.11.11.11?path=c:\temp\auth.xml,12.12.12.12,13.13.13.13?name=profA,secret=foo,14.14.14.14"
 *
 * The above connection string will be parsed, and the resulting elements will be put into 
 * the outConnectionStrings array as follows:
 * outConnectionStrings[0] = 10.10.10.10?path=c:\temp\auth.xml
 * outConnectionStrings[1] = 11.11.11.11?path=c:\temp\auth.xml
 * outConnectionStrings[2] = 12.12.12.12?name=profA,secret=foo
 * outConnectionStrings[3] = 13.13.13.13?name=profA,secret=foo
 * outConnectionStrings[4] = 14.14.14.14
 *
 * Notice in example two that the pea file and credentials given are valid for all IP 
 * addresses listed prior to the credential list that do not already have credentials 
 * specifically specified after them. 
 *
 * NOTE: If the connection string includes the use of a path pointing to a pea file and 
 *       the "name=" and/or "secret=", the path MUST come first if the "path=" prefix is
 *       not used in order for this function to work correctly.
 *       example:
 *       10.10.10.10?c:\temp\auth.xml,name=myProf,secret=mySecret      (VALID)
 *       10.10.10.10?name=myProf,secret=mySecret,c:\temp\auth.xml      (INVALID)
 *       10.10.10.10?name=myProf,c:\temp\auth.xml,secret=mySecret      (INVALID)
 *       10.10.10.10"name=myProf,secret=mySecret,path=c:\temp\auth.xml (VALID)
 *
 * NOTE: Credentials included in the connection string will always override the credentials
 *       in the pea file. 
 *       Although this function handles the case where the passed in connection string may 
 *       have mixed pea data attached to a single IP address (first example above) it is 
 *       not recommended the user pass connection strings this way.  
 *       For example, consider the following connection string:
 *       
 *         10.10.10.10?c:\temp\auth.xml,name=myProf,secret=mySecret
 *       
 *       The credentials referenced in the c:\temp\auth.xml file will be 
 *       overridden with the name=myProf,secret=mySecret credentials instead.
 *      
 *       Also if the connection string has mixed pea data attached and the mixed data
 *       given is a path and only one other credential (either name=<name> 
 *       or secret=<secret>), then the credentials used by the software will be a mixture 
 *       of the credentials included in the pea file, and the credentials listed in the 
 *       connection string.
 *       For example: Assume the pea file c:\temp\auth.pea contains a name credential 
 *                    of "MyName" and a secret credential of "MySecret" and the following
 *                    connection string is provided:
 *
 *         10.10.10.10?c:\temp\auth.pea,name=JohnSmith
 *
 *       The order given in the connection string for credential information does not 
 *       matter with regards to if a name and/or secret pair will override the credentials 
 *       in the pea file. As stated before, if a name and/or secret is provided in the 
 *       connection string along with a path to a pea file, the name and/or secret 
 *       credentials specified in the connection string will override the credentials in 
 *       the pea file pointed to.
 *       For example: Assume the pea file c:\temp\auth.pea contains a name credential 
 *                    of "MyName" and a secret credential of "MySecret" and the following
 *                    connection string is provided:
 *
 *         10.10.10.10?name=JohnSmith,path=c:\temp\auth.pea
 *
 *       The result of this example is the same as the example above this one.
 *       A call to the PAI_GetUserName(...) function will yield "JohnSmith"
 *       and a call to the PAI_GetCredential(...) function will yield "MySecret". 
 *       As you can see this can cause confusion and this is why it is recommended to
 *       NOT mix credential data in a connection string.
 *
 * @param inConnectionString The connection string to parse
 * @param outConnectionStrings A NULL char** pointer that this function allocates 
 *                             memory for and populates with the resulting elements as 
 *                             stated above. 
 *                             The caller of this function is responsible for releasing 
 *                             the resultant array by using the 
 *                             PAI_FreeProfileClusterStrings(...) function of the 
 *                             PAI module.
 *                             Example of use:
 * 
 *                             int numElements = 0;
 *                             char** myArray = NULL;
 *                             const char* conStr = someConnectionStr;
 *                             long retVal = PAI_GetProfileClusters (conStr, 
 *                                                                   &myArray, 
 *                                                                   &numElements);
 *                             //code that uses myArray here
 *
 *                             //release the memory associated with the array
 *                             PAI_FreeProfileClusterStrings(&myArray, numElements);
 *
 *
 * @param outNumberOfConnectionStrings On input, ignored
 *                                     On output, the number of elements actually 
 *                                     contained in the array. 
 * @return One of the PAI error code definitions found in PAI_types.h
 */
PAI_MODULE_API long
PAI_GetProfileClusters (const char* inConnectionString, 
                        char*** outConnectionStrings, 
                        int* outNumberOfConnectionStrings);

/**
 * @param inConnectionString A char** pointer that was created by calling the 
 *                           PAI_GetProfileClusters(...) function. Any other char** pointer
 *                           that is passed to this function will result in a crash.
 * @param inNumOfElements The number of elements contained in the passed in char** pointer.
 *                        This value should be the out put result of the int pointer that
 *                        is used in the PAI_GetProfileClusters(...) function call that
 *                        was used to create the passed in char** pointer.
 * @see PAI_GetProfileClusters
 */
PAI_MODULE_API void
PAI_FreeProfileClusterStrings (char*** inConnectionStringsArray, int inNumOfElements);

////////////////////////////////////////////////////////////////////////////////
// C API to the PAI class - Credential Store Management section
////////////////////////////////////////////////////////////////////////////////
/**
 * PAI_Create - create a new profile using information in the poolname
 *
 * @param a char pointer to the poolname
 * @param a pointer to a PAI ref to update on successful creation of the profile
 *
 * @returns PAI_AOK on success
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 * @returns PAI_POOL_EXISTS if the poolname references an existing profile
 */
PAI_MODULE_API long
PAI_Create (const char *inPoolName, PAIRef *outRef);

/**
 * PAI_AddUserName - add access information to the profile
 *
 * @param a PAI ref (set by PAI_Initialize or PAI_Create)
 * @param a char pointer indicating the type of section (currently,
 *        only sections of type "cluster" are supported)
 * @param a char pointer to the section name
 * @param a char pointer to the user name
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 * @returns PAI_UNKNOWN_CLUSTERID if the cluster ID is not found
 */
PAI_MODULE_API long
PAI_AddUserName (PAIRef inRef,
				 char *inKeyType, char *inKey,
                 char *inName);

/**
 * PAI_AddCredential - add access information to the profile
 *
 * @param a PAI ref (set by PAI_Initialize or PAI_Create)
 * @param a char pointer indicating the type of section (currently,
 *        only sections of type "cluster" are supported)
 * @param a char pointer to the section name
 * @param a char pointer to the credential ID
 * @param a char pointer to the credential
 * @param an unsigned short or size_t, depending on the platform, 
 *        containing the number of bytes in the credential
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 * @returns PAI_UNKNOWN_CLUSTERID if the cluster ID is not found
 */
PAI_MODULE_API long
PAI_AddCredential (PAIRef inRef,
                   char *inKeyType, char *inKey,
                   char *inCredentialID,
                   char *inCredential, PAI_UNSIGNED_SHORT inCredentialLen);

/**
 * PAI_DeleteAccessInfo - delete access information from the profile
 *
 * @param a PAI ref (set by PAI_Initialize or PAI_Create)
 * @param a char pointer indicating the type of section (currently,
 *        only sections of type "cluster" are supported)
 * @param a char pointer to the section name
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 * @returns PAI_UNKNOWN_CLUSTERID if the cluster ID is not found
 */
PAI_MODULE_API long
PAI_DeleteAccessInfo (PAIRef inRef, char *inKeyType, char *inKey);

/**
 * PAI_Update - commit any changes made to the profile 
 *
 * @param a PAI ref (set by PAI_Initialize or PAI_Create)
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 */
PAI_MODULE_API long
PAI_Update (PAIRef inRef);

/**
 * PAI_Delete - delete the profile information from the store 
 *
 * @param a PAI ref (set by PAI_Initialize or PAI_Create)
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 * @returns PAI_NO_ACCESS if not allowed to access the credential store
 */
PAI_MODULE_API long
PAI_Delete (PAIRef inRef);

/**
 * PAI_Close - Close the open reference and free any resources 
 *
 * @param a PAI ref (set by PAI_Initialize or PAI_Create)
 *
 * @returns PAI_AOK on success
 * @returns PAI_BAD_REFERENCE if the PAI reference is badly formed
 */
PAI_MODULE_API long
PAI_Close (PAIRef inRef);

} // end of extern "C"

#endif // __PAI_API_H_
