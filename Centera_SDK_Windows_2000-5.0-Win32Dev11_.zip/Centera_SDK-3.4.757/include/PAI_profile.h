/******************************************************************************\
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * All Rights Reserved
 *
 * PAI_profile.h
 *
 * PAI module Header File Build Version 3.4.107
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/
/******************************************************************************\
 *
 * The reference implementation of a Pool Access Information (PAI) module
 *
 * This file defines the class actually used to interact with the credential
 * store. In the reference implementation, the credential store is the local 
 * file system. Information (aka a "profile") is bound to a poolname using 
 * a file in the aformementioned file system.
 *
 * EDIT THE IMPLEMENTATION OF THIS CLASS when implementing a PAI module!!!
 * 
\******************************************************************************/
#ifndef __PAI_PROFILE_H_
#define __PAI_PROFILE_H_

#include "PAI_types.h"

/**
 * Data structure for keyed segment of access information
 */
typedef struct section_t {
	// section identifiers
	char *keyType;
	char *key;

	// username
	char *userName;

	// credentials
	int nCredentials;
	char **credentialID;
	char **credential;
	PAI_INT *credentialLen;
} section_t;


/////////////////////////////////////////////////////////////////////////////////
/**
 * PAI_profile - access information associated with profile(s)
 */
class PAI_profile 
{
 public:
	////////////////////////////////////////////////////////////////////////////
	// Public data
	////////////////////////////////////////////////////////////////////////////
	PAIRef ID;

	// elements of the passed in pool address (raw strings)
	char *poolName;
	char *poolAddress;
	char *profilePath;
	char *profileName;
	char *profileSecret;

	// actual authentication data
	section_t def;
	int nSections;
	int maxSections;
	section_t *section;

 protected:
	////////////////////////////////////////////////////////////////////////////
	// Internal methods
	////////////////////////////////////////////////////////////////////////////
	long parsePathElement(const char *inPathElement);
	long parsePath(const char *inProfilePath);
	int getSectionIndex (const char *inKeyType, const char *inKey);

 public:
	////////////////////////////////////////////////////////////////////////////
	// Public methods
	////////////////////////////////////////////////////////////////////////////
	long getVersion (char *outVersion, PAI_UNSIGNED_SHORT *ioVersionLen);
	long getAddress (char *outAddress, PAI_UNSIGNED_SHORT *ioAddressLen);

	long getUserName   (char *inKeyType, char *inKeyID, 
	                    char *outName, PAI_UNSIGNED_SHORT *ioNameLen);
	long getCredential (char *inKeyType, char *inKeyID,
	                    char *inCredentialID, 
	                    char *outCredential, PAI_UNSIGNED_SHORT *ioCredentialLen);

	long setUserName   (const char *inKeyType, const char *inKey, 
                        const char *inUserName);
	long setCredential (const char *inKeyType, const char *inKey, 
                        const char *inCredentialID,
                        const char *inCredential, PAI_UNSIGNED_SHORT inCredentialLen);

	long deleteAccessInfo (const char *inKeyType, const char *inKey);

	long load (void);   // read profile from the credential store
	long update (void);	// update profile in the credential store
	long remove (void);	// delete profile from credential store

	////////////////////////////////////////////////////////////////////////////
	// Constructors
	////////////////////////////////////////////////////////////////////////////
	/**
	 * Copy a PAI_profile
	 *
	 * @param inProfile A PAI_profile reference
	 */
	PAI_profile (PAI_profile &inProfile);
	
	/**
	 * Construct a new PAI_profile
	 *
	 * @param inID An identifier to bind the information to 
	 * @param inPoolName The poolname as passed to the SDK 
	 */
	PAI_profile (PAIRef inID, const char *inPoolName); 

	////////////////////////////////////////////////////////////////////////////
	// Destructor
	////////////////////////////////////////////////////////////////////////////
	/**
	 * Release any resources
	 */
	~PAI_profile (void);
};

#endif // __PAI_PROFILE_H_
