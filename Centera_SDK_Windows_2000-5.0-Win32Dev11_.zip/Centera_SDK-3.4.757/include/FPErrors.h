
#ifndef __FPERRORS__
#define __FPERRORS__
/*****************************************************************************
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * Unpublished - All Rights Reserved
 *
 * FPErrors.h
 *
 * FPLibrary Header File Build Version 3.4.757
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
 * EMC2  , EMC, Symmetrix, Celerra, CLARiiON, CLARalert, DG, E-Infostructure, 
 * HighRoad, Navisphere, PowerPath, ResourcePak, SnapView/IP, SRDF, VisualSAN, 
 * where information lives, and The EMC Effect are registered trademarks and EMC 
 * Automated Networked Storage, EMC ControlCenter, EMC Developers Program, EMC 
 * Enterprise Storage, EMC Enterprise Storage Network, EMC OnCourse, EMC Proven, 
 * EMC Snap, Access Logix, AutoAdvice, Automated Resource Manager, AutoSwap, 
 * AVALONidm, C-Clip, CacheStorm, Celerra Replicator, Centera, CentraStar, 
 * CLARevent, Connectrix, CopyCross, CopyPoint, CrosStor, Direct Matrix, Direct 
 * Matrix Architecture, EDM, E-Lab, Enginuity, FarPoint, FLARE, GeoSpan, InfoMover, 
 * MirrorView, NetWin, OnAlert, OpenScale, Powerlink, PowerVolume, RepliCare, 
 * SafeLine, SAN Architect, SAN Copy, SAN Manager, SDMS, SnapSure, SnapView, 
 * StorageScope, SupportMate, SymmAPI, SymmEnabler, Symmetrix DMX, TimeFinder, 
 * Universal Data Tone, and VisualSRM are trademarks of EMC Corporation. All other 
 * trademarks used herein are the property of their respective owners.
 *
 * ---------------------------------------------------------------------------
 * Copyright ) 1991-2, RSA Data Security, Inc. Created 1991.
 * All rights reserved.
 * License to copy and use this software is granted provided
 * that it is identified as the "RSA Data Security, Inc. MD5
 * Message-Digest Algorithm" in all material mentioning or
 * referencing this software or this function.
 * RSA Data Security, Inc. makes no representations concerning
 * either the merchantability of this software or the
 * suitability of this software for any particular purpose. It
 * is provided "as is" without express or implied warranty of any kind.
 *
 * These notices must be retained in any
 * copies of any part of this documentation and/or software.
 *
 * ---------------------------------------------------------------------------
 * Copyright and Licensing Information for ACE(TM)
 * http://www.cs.wustl.edu/~schmidt/ACE-copying.html
 *
 *****************************************************************************/

/**
  @file FPErrors.h
   FPLibrary Error Definitions.
*/

/** @defgroup Errors Errors
    @{ */

 #define FP_ERROR_BASE          -10000           /**< version 1.0 errors                                                            */                

 #define FP_INVALID_NAME            (FP_ERROR_BASE-1)   /**< The name is not XML compliant                                          */
 #define FP_UNKNOWN_OPTION          (FP_ERROR_BASE-2)   /**< Unknown option name with FP_SetIntOption/GetIntOption                  */
 #define FP_NOT_SEND_REQUEST_ERR    (FP_ERROR_BASE-3)   /**< Error sending a request to the server                                  */
 #define FP_NOT_RECEIVE_REPLY_ERR   (FP_ERROR_BASE-4)   /**< Error receiving a reply from the server                                */
 #define FP_SERVER_ERR              (FP_ERROR_BASE-5)   /**< The server reported an error from the operation                        */
 #define FP_PARAM_ERR               (FP_ERROR_BASE-6)   /**< Incorrect or unknown parameter detected                                */
 #define FP_PATH_NOT_FOUND_ERR      (FP_ERROR_BASE-7)   /**< Path does not correspond to a file/directory on the local system       */
 #define FP_CONTROLFIELD_ERR        (FP_ERROR_BASE-8)   /**< SDK 2.0: no longer used                                                */
 #define FP_SEGDATA_ERR             (FP_ERROR_BASE-9)   /**< SDK 2.0: no longer used                                                */
 #define FP_DUPLICATE_FILE_ERR      (FP_ERROR_BASE-10)  /**< Duplicate blob found on server                                         */
 #define FP_OFFSET_FIELD_ERR        (FP_ERROR_BASE-11)  /**< SDK 2.0: no longer used                                                */
 #define FP_OPERATION_NOT_SUPPORTED (FP_ERROR_BASE-12)  /**< Operation not (yet) supported (e.g. on flat C-Clip)                    */
 #define FP_ACK_NOT_RCV_ERR         (FP_ERROR_BASE-13)  /**< Write acknowledgement not received                                     */
 #define FP_FILE_NOT_STORED_ERR     (FP_ERROR_BASE-14)  /**< Blob could not be stored on write or could not be found on import      */
 #define FP_NUMLOC_FIELD_ERR        (FP_ERROR_BASE-15)  /**< SDK 2.0: no longer used                                                */
 #define FP_SECTION_NOT_FOUND_ERR   (FP_ERROR_BASE-16)  /**< SDK 2.0: no longer used                                                */
 #define FP_TAG_NOT_FOUND_ERR       (FP_ERROR_BASE-17)  /**< Tag in C-Clip description file not found                               */
 #define FP_ATTR_NOT_FOUND_ERR      (FP_ERROR_BASE-18)  /**< Attribute with that name not found                                     */
 #define FP_WRONG_REFERENCE_ERR     (FP_ERROR_BASE-19)  /**< You have used an invalid reference                                     */
 #define FP_NO_POOL_ERR             (FP_ERROR_BASE-20)  /**< No connection with any pool                                            */
 #define FP_CLIP_NOT_FOUND_ERR      (FP_ERROR_BASE-21)  /**< ClipFile (CDF) is not found in the pool                                */
 #define FP_TAGTREE_ERR             (FP_ERROR_BASE-22)  /**< An error in the tag tree was discovered                                */
 #define FP_ISNOT_DIRECTORY_ERR     (FP_ERROR_BASE-23)  /**< We expect a path to a directory, not to a file                         */
 #define FP_UNEXPECTEDTAG_ERR       (FP_ERROR_BASE-24)  /**< We expected either a 'file' or 'folder' tag                            */
 #define FP_TAG_READONLY_ERR        (FP_ERROR_BASE-25)  /**< The tag cannot be changed or deleted                                   */
 #define FP_OUT_OF_BOUNDS_ERR       (FP_ERROR_BASE-26)  /**< The options parameter is out of bounds                                 */
 #define FP_FILESYS_ERR             (FP_ERROR_BASE-27)  /**< A file system error occurred (e.g. fopen on unknown file)              */
 
 #define FP_STACK_DEPTH_ERR         (FP_ERROR_BASE-29)  /**< Maximum depth of enclosing tags is reached                             */
 #define FP_TAG_HAS_NO_DATA_ERR     (FP_ERROR_BASE-30)  /**< The tag does not contain blob data                                     */
 #define FP_VERSION_ERR             (FP_ERROR_BASE-31)  /**< Mismatch between C-Clip version and current software version           */
 #define FP_MULTI_BLOB_ERR          (FP_ERROR_BASE-32)  /**< The tag has already data associated with it                            */
 #define FP_PROTOCOL_ERR            (FP_ERROR_BASE-33)  /**< Unknown protocol option                                                */
 #define FP_NO_SOCKET_AVAIL_ERR     (FP_ERROR_BASE-34)  /**< No new socket is available for the transaction                         */
 #define FP_BLOBIDFIELD_ERR         (FP_ERROR_BASE-35)  /**< SDK 2.0: no longer used                                                */
 #define FP_BLOBIDMISMATCH_ERR      (FP_ERROR_BASE-36)  /**< BlobID mismatch between client & server, blob is corrupt               */
 #define FP_PROBEPACKET_ERR         (FP_ERROR_BASE-37)  /**< SDK 2.0: no longer used                                                */
 #define FP_CLIPCLOSED_ERR          (FP_ERROR_BASE-38)  /**< The FPClip this object belongs to is already closed (Java only)        */
 #define FP_POOLCLOSED_ERR          (FP_ERROR_BASE-39)  /**< The FPPool this object belongs to is already closed (Java only)        */
 #define FP_BLOBBUSY_ERR            (FP_ERROR_BASE-40)  /**< The blob on the server is busy and cannot be read or written to        */
 #define FP_SERVER_NOTREADY_ERR     (FP_ERROR_BASE-41)  /**< The server is not yet ready to process your request                    */
 #define FP_SERVER_NO_CAPACITY_ERR  (FP_ERROR_BASE-42)  /**< The server has no capacity to store this data                          */
 #define FP_DUPLICATE_ID_ERR        (FP_ERROR_BASE-43)  /**< App passed in a sequence ID that was used before                       */
 #define FP_STREAM_VALIDATION_ERR   (FP_ERROR_BASE-44)  /**< Detected a generic stream validation error                     */
 #define FP_STREAM_BYTECOUNT_MISMATCH_ERR (FP_ERROR_BASE-45) /**< Detected a generic stream bytecount mismatch                      */


 #define FP_NETWORK_ERROR_BASE   -10100          /**< network related errors                                                        */
 #define FP_SOCKET_ERR           (FP_NETWORK_ERROR_BASE-1)      /**< Error on network socket                                        */
 #define FP_PACKETDATA_ERR       (FP_NETWORK_ERROR_BASE-2)      /**< Wrong data in packet                                           */
 #define FP_ACCESSNODE_ERR       (FP_NETWORK_ERROR_BASE-3)      /**< No Access Node can be found                                    */
                                                                                                                                   
 #define FP_SERVER_ERROR_BASE    -10150          /**< server related errors                                                         */
 #define FP_OPCODE_FIELD_ERR                   (FP_SERVER_ERROR_BASE-1)    /**< The Query Opcode field is missing from the packet            */
 #define FP_PACKET_FIELD_MISSING_ERR           (FP_SERVER_ERROR_BASE-2)    /**< The packet field is missing                                  */
 #define FP_AUTHENTICATION_FAILED_ERR          (FP_SERVER_ERROR_BASE-3)    /**< Authentication failed                                        */
 #define FP_UNKNOWN_AUTH_SCHEME_ERR            (FP_SERVER_ERROR_BASE-4)    /**< Unknown authentication scheme                                */
 #define FP_UNKNOWN_AUTH_PROTOCOL_ERR          (FP_SERVER_ERROR_BASE-5)    /**< Unknown authentication protocol                              */
 #define FP_TRANSACTION_FAILED_ERR             (FP_SERVER_ERROR_BASE-6)    /**< Transaction on the server failed                             */
 #define FP_PROFILECLIPID_NOTFOUND_ERR         (FP_SERVER_ERROR_BASE-7)    /**< There was no profile clip found                              */
 #define FP_ADVANCED_RETENTION_DISABLED_ERR    (FP_SERVER_ERROR_BASE-8)    /**< Compliance feature not supported                             */
 #define FP_NON_EBR_CLIP_ERR                   (FP_SERVER_ERROR_BASE-9)    /**< Attempt to trigger an ebr event on a non-ebr clip            */
 #define FP_EBR_OVERRIDE_ERR                   (FP_SERVER_ERROR_BASE-10)   /**< Attempt to set ebr information a second time                 */
 #define FP_NO_EBR_EVENT_ERR                   (FP_SERVER_ERROR_BASE-11)   /**< Attempt to delete a clip which is waiting under ebr          */
 #define FP_RETENTION_OUT_OF_BOUNDS_ERR        (FP_SERVER_ERROR_BASE-12)   /**< Attempt to set a retention period outside min/max range      */
 #define FP_RETENTION_HOLD_COUNT_ERR           (FP_SERVER_ERROR_BASE-13)   /**< Attempt to set more holds than allowed                       */
 #define FP_METADATA_MISMATCH_ERR              (FP_SERVER_ERROR_BASE-14)   /**< Mutable metadata mismatch found                              */
 #define FP_METADATA_CONSTRAINT_ERR            (FP_SERVER_ERROR_BASE-15)   /**< Mutable metadata constraint error                            */

 #define FP_CLIENT_ERROR_BASE    -10200          /**<  client errors                                                                */
                                                                                                                                  
 #define FP_OPERATION_REQUIRES_MARK    (FP_CLIENT_ERROR_BASE-1)  /**< The application requires marker support but the stream does not provide it  */
 #define FP_QUERYCLOSED_ERR            (FP_CLIENT_ERROR_BASE-2)  /**< The FPQuery for this object is already closed (Java only)                   */
 #define FP_WRONG_STREAM_ERR           (FP_CLIENT_ERROR_BASE-3)  /**< The method expects an input stream and Gets an output stream or vice-versa  */
 #define FP_OPERATION_NOT_ALLOWED      (FP_CLIENT_ERROR_BASE-4)  /**< The use of this operation is restricted                                     */
 #define FP_SDK_INTERNAL_ERR           (FP_CLIENT_ERROR_BASE-5)  /**< An SDK internal programming error was detected                              */
 #define FP_OUT_OF_MEMORY_ERR          (FP_CLIENT_ERROR_BASE-6)  /**< System ran out of memory                                                    */
 #define FP_OBJECTINUSE_ERR            (FP_CLIENT_ERROR_BASE-7)  /**< Cannot close the object because it is still in use                          */
 #define FP_NOTYET_OPEN_ERR            (FP_CLIENT_ERROR_BASE-8)  /**< The object is not yet opened                                                */
 #define FP_STREAM_ERR                 (FP_CLIENT_ERROR_BASE-9)  /**< An error in the generic stream occurred                                     */
 #define FP_TAGCLOSED_ERR              (FP_CLIENT_ERROR_BASE-10) /**< The FPTag for this object is already closed (Java only)                     */
 #define FP_THREAD_ERR                 (FP_CLIENT_ERROR_BASE-11) /**< Error creating background thread                                            */
 #define FP_PROBE_TIME_EXPIRED_ERR     (FP_CLIENT_ERROR_BASE-12) /**< The probe limit time was reached                                            */
 #define FP_PROFILECLIPID_WRITE_ERR    (FP_CLIENT_ERROR_BASE-13) /**< There was an error while storing the profile clip ID                        */
 #define FP_INVALID_XML_ERR            (FP_CLIENT_ERROR_BASE-14) /**< The specified string is not valid XML                                       */
 #define FP_UNABLE_TO_GET_LAST_ERROR   (FP_CLIENT_ERROR_BASE-15) /**< There was an error reporting the last error                                 */
 #define FP_LOGGING_CALLBACK_ERR     (FP_CLIENT_ERROR_BASE-16) /**< An error occurred in the application defined FPLogging callback             */
 #define FP_MIGRATION_ERR              (FP_CLIENT_ERROR_BASE-17) /**< The write portion of a piped stream encountered an error. Write error is wrapped.       */
 #define FP_COLLOCATION_ERR            (FP_CLIENT_ERROR_BASE-18) /**< Encountered an error during collocate. Write error is wrapped.       */
 #define FP_REDIRECTED_ERR             (FP_CLIENT_ERROR_BASE-19) /**< Can�t continue current operation because server issued a valid redirect but it could not be honored. */
 #define FP_INVALID_REDIRECT_ERR       (FP_CLIENT_ERROR_BASE-20) /**< Server issued a redirect either without providing a redirect packet or redirected to an ineligible cluster. */  
 #define FP_FEDERATED_VER_ERR              (FP_CLIENT_ERROR_BASE-21) /**< Detected federated version different than original.   */ 
 #define FP_INVALID_FEDERATION_ERR     (FP_CLIENT_ERROR_BASE-22) /**< The federation being used does not have any active members.   */ 
 
 #define FP_UNDEFINED_ERROR_BASE -10250          /**< for future expansion                                                                       */
 

/* The following codes are outside the API proper and are set by the stub (FPZstub.c) itself                                               */ 
/* For ABEND and unknown RC, the systemError field from FPPool_GetLastErrorInfo will contain these codes.                                  */ 
 
 #define FP_ZOS_ERROR_BASE       -20000          /**< zOS mainframe port "GLUE LAYER" related errors                                       */
 #define FP_SUBTASK_TCB_NOT_FOUND   (FP_ZOS_ERROR_BASE-1)       /**< The subtask TCB address was NULL (subtask not found)                        */        
 #define FP_INVALID_FUNCTION_ID     (FP_ZOS_ERROR_BASE-2)       /**< Invalid numeric function identifier encountered in subtask                  */        
 #define FP_COMMAREA_MALLOC_ERR     (FP_ZOS_ERROR_BASE-3)       /**< Unable to malloc a commarea                                                 */        
 #define FP_ZOS_SUBTASK_ABEND       (FP_ZOS_ERROR_BASE-4)       /**< zOS mainframe port : subtask abend                                          */
 #define FP_ZOS_SUBTASK_UNKN_RC     (FP_ZOS_ERROR_BASE-5)       /**< zOS mainframe port : subtask abnormal return code                           */

/* The following codes are bases from which the component error codes are subtracted.                                                       */
/* These are handled this way because a commarea in which to store the systemError field cannot be obtained.                                */
/* (Base code may be returned if no specifice code is available.)                                                                           */ 
 
 #define FP_ZOS_IEANTCR_BASE     -20100          /**< zOS mainframe port : Name-Token services create                                       */
 #define FP_ZOS_IEANTDL_BASE     -20200          /**< zOS mainframe port : Name-Token services delete                                       */
 #define FP_ZOS_IEANTRT_BASE     -20300          /**< zOS mainframe port : Name-Token services retrieve                                     */

/** @} */ /* Errors */

#endif /* __FPERRORS__ */

