#ifndef __FPSHA256_INTERFACE_HEADER__
#define __FPSHA256_INTERFACE_HEADER__

/*****************************************************************************
 *
 * Copyright (c) 2005-2005 EMC Corporation
 * Unpublished - All Rights Reserved
 *
 * FPSHA256_Interface.h
 *
 * FPLibrary Header File Build Version 3.4.757
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile 
 * and the intellectual property contained therein is expressly limited to the 
 * terms and conditions of the License Agreement.
 *
 * EMC2  , EMC, Symmetrix, Celerra, CLARiiON, CLARalert, DG, E-Infostructure, 
 * HighRoad, Navisphere, PowerPath, ResourcePak, SnapView/IP, SRDF, VisualSAN, 
 * where information lives, and The EMC Effect are registered trademarks and EMC 
 * Automated Networked Storage, EMC ControlCenter, EMC Developers Program, EMC 
 * Enterprise Storage, EMC Enterprise Storage Network, EMC OnCourse, EMC Proven, 
 * EMC Snap, Access Logix, AutoAdvice, Automated Resource Manager, AutoSwap, 
 * AVALONidm, C-Clip, CacheStorm, Celerra Replicator, Centera, CentraStar, 
 * CLARevent, Connectrix, CopyCross, CopyPoint, CrosStor, Direct Matrix, Direct 
 * Matrix Architecture, EDM, E-Lab, Enginuity, FarPoint, FLARE, GeoSpan, InfoMover, 
 * MirrorView, NetWin, OnAlert, OpenScale, Powerlink, PowerVolume, RepliCare, 
 * SafeLine, SAN Architect, SAN Copy, SAN Manager, SDMS, SnapSure, SnapView, 
 * StorageScope, SupportMate, SymmAPI, SymmEnabler, Symmetrix DMX, TimeFinder, 
 * Universal Data Tone, and VisualSRM are trademarks of EMC Corporation. All other 
 * trademarks used herein are the property of their respective owners.
 *
 * ---------------------------------------------------------------------------
 *
 * Based on: US Secure Hash Algorithms (SHA and HMAC-SHA)
 *           Copyright (C) The Internet Society (2006).
 * 
 *           Website: http://tools.ietf.org/html/rfc4634
 *           License: http://tools.ietf.org/html/rfc4634#section-1.1
 *
 *           Permission is granted for all uses, commercial and non-commercial, of
 *           the sample code found in Section 8.  Royalty free license to use,
 *           copy, modify and distribute the software found in Section 8 is
 *           granted, provided that this document is identified in all material
 *           mentioning or referencing this software, and provided that
 *           redistributed derivative works do not contain misleading author or
 *           version information.
 *
 *           The authors make no representations concerning either the
 *           merchantability of this software or the suitability of this software
 *           for any particular purpose.  It is provided "as is" without express
 *           or implied warranty of any kind.
 *
 *****************************************************************************/

#include "FPTypes.h"

#ifdef __cplusplus
extern "C" {
#endif

//////////////////////////////////////////////////////////////////////////////
//            REQUIRED FUNCTIONS TO IMPLEMENT
//////////////////////////////////////////////////////////////////////////////

/**
    Creates, initializes, and returns a newly allocated context that is used as a 
    parameter for all other SHA256 library APIs.

    @return The newly created context that is used to hold the state of the
            SHA256 hash and anything else the implementer sees fit, OR
            NULL if an error occurs.
 */
EXPORT void* DECL SHA256Lib_CreateContext (void);



/**
     SHA256 block update operation. This function continues an SHA256 message-digest 
     operation, processing another message block, and updating the passed in 
     context.

     @param ioContext on input A previous returned context from either 
                               SHA256Lib_CreateContext() or SHA256Lib_Update(...)
                      on output The updated SHA256 context.

     @param inBuf A buffer holding the data to be hashed
     @param inBufLen The length of the inBuf
     @return Zero (0) if no error or 
             a negative value on error
 */
EXPORT int DECL SHA256Lib_Update(void* ioContext, char* inBuf, unsigned long inBufLen);

/**
    SHA256 finalization. This function ends an SHA256 message-digest operation, 
    writing the message digest to the outDigest array.

    @param outDigest[SHA256HashSize] Buffer that is populated with 128 bits of SHA256 hash
    @param inContext The returned value (if not NULL) from the 
                     SHA256Lib_CreateContext() function call.
    @return Zero (0) if no error or 
            a negative value on error
 */
EXPORT int DECL SHA256Lib_Final(unsigned char outDigest[32], void* inContext);

/**
    Releases the resources associated with the passed in context.
    @param inContext The returned value (if not NULL) from the 
                     SHA256Lib_CreateContext() function call.
    @return Zero (0) if no error or 
            a negative value on error
 */
EXPORT int DECL SHA256Lib_DeleteContext(void * inContext);

//////////////////////////////////////////////////////////////////////////////
//            NON-REQUIRED FUNCTIONS TO IMPLEMENT
//////////////////////////////////////////////////////////////////////////////

/**
    NOTE: It is NOT required that the implementer of this interface implement this 
          function. If this interface is implemented without this function the SDK 
          will default to using its own implementation of the SHA256 algorithm when
          neede.

    Creates an SHA256 context that is based on the raw SHA256 state (no padding) 
    of a previously, partially, calculated SHA256 context. 

    @param inRawSHA256State A NULL terminated SHA256 string that was calculated from
                         a context's raw state.
    @param inDataLen How much data (in bytes) have been used to calculate 
                     the passed in inRawSHA256State data. This value is used to re-build 
                     the 'count' portion of the SHA256 context.
     @return The newly created context that is holding the current passed in state of the
             SHA256 hash OR
             NULL if an error occurs. 
 */
EXPORT void* DECL SHA256Lib_CreatePartialContext (const char* inRawSHA256State, FPLong inDataLen);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // __FPSHA256_INTERFACE_HEADER__

