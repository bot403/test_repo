
/*****************************************************************************
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * Unpublished - All Rights Reserved
 *
 * FPTypes.h
 *
 * FPLibrary Header File Build Version 3.4.757
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile 
 * and the intellectual property contained therein is expressly limited to the 
 * terms and conditions of the License Agreement.
 *
 * EMC2  , EMC, Symmetrix, Celerra, CLARiiON, CLARalert, DG, E-Infostructure, 
 * HighRoad, Navisphere, PowerPath, ResourcePak, SnapView/IP, SRDF, VisualSAN, 
 * where information lives, and The EMC Effect are registered trademarks and EMC 
 * Automated Networked Storage, EMC ControlCenter, EMC Developers Program, EMC 
 * Enterprise Storage, EMC Enterprise Storage Network, EMC OnCourse, EMC Proven, 
 * EMC Snap, Access Logix, AutoAdvice, Automated Resource Manager, AutoSwap, 
 * AVALONidm, C-Clip, CacheStorm, Celerra Replicator, Centera, CentraStar, 
 * CLARevent, Connectrix, CopyCross, CopyPoint, CrosStor, Direct Matrix, Direct 
 * Matrix Architecture, EDM, E-Lab, Enginuity, FarPoint, FLARE, GeoSpan, InfoMover, 
 * MirrorView, NetWin, OnAlert, OpenScale, Powerlink, PowerVolume, RepliCare, 
 * SafeLine, SAN Architect, SAN Copy, SAN Manager, SDMS, SnapSure, SnapView, 
 * StorageScope, SupportMate, SymmAPI, SymmEnabler, Symmetrix DMX, TimeFinder, 
 * Universal Data Tone, and VisualSRM are trademarks of EMC Corporation. All other 
 * trademarks used herein are the property of their respective owners.
 *
 * ---------------------------------------------------------------------------
 * Copyright ) 1991-2, RSA Data Security, Inc. Created 1991. 
 * All rights reserved. 
 * License to copy and use this software is granted provided 
 * that it is identified as the "RSA Data Security, Inc. MD5 
 * Message-Digest Algorithm" in all material mentioning or 
 * referencing this software or this function. 
 * RSA Data Security, Inc. makes no representations concerning 
 * either the merchantability of this software or the 
 * suitability of this software for any particular purpose. It 
 * is provided "as is" without express or implied warranty of any kind. 
 *
 * These notices must be retained in any 
 * copies of any part of this documentation and/or software.
 *
 * ---------------------------------------------------------------------------
 * Copyright and Licensing Information for ACE(TM)
 * http://www.cs.wustl.edu/~schmidt/ACE-copying.html
 *
 *****************************************************************************/

#ifndef __FPTYPES__
#define __FPTYPES__

/**
  @file FPTypes.h
   FPLibrary Type Definitions.
   FPLibrary uses the type definitions in this file to make the API platform independent.
*/

/** @defgroup Types Platform Independent Types
    @{ */

/* ------------ Compiler/OS Dependency */
#ifdef __MWERKS__       /* MetroWerks CodeWarrior compiler */

  #include <ansi_parms.h>
  #if __dest_os==__win32_os
   #ifndef WIN32
    #define WIN32     1
   #endif
  #elif __dest_os==__mac_os
    #define MACOS9    1 /* need for further discrimination */
    #define MACOSX    1
  #endif

#endif  
#ifdef _MSC_VER        /* Visual C++ */

  #ifndef WIN32
    #ifndef WIN64
      #define WIN32     1
    #endif
  #endif /* WIN32 */

  #define ENOERR    0                       /* missing from errno.h... */

  #if _MSC_VER < 1300                       /* 1200 == VC++ 6.0 */
  #ifndef LLONG_MAX
    #define LLONG_MAX _I64_MAX              /* maximum LONGLONG value: 9223372036854775807 */
  #endif /* LLONG_MAX */
  #endif

#endif /* _MSC_VER */

#if defined(POSIX) || defined(__GNUC__)
  #define ENOERR    0
#endif

/*------------ System Includes */
#if defined(WIN32) && defined(__GNUC__)
#  include <stdint.h>
#endif

/* The following is adapted from the IBM C/C++ inttypes.h. SAS/C  *
 * does not appear to have a consistent set of these definitions. *
 * __int64 is defined, but __int32 and __int16 are not.
 * Note that SAS/C 6.50 does not support 64 bit integers.
 */
#ifdef __SASC__
   typedef    signed    short       int16_t;
   typedef    signed    int         int32_t;

#if  __SASC__!=650
   typedef    signed    long long   int64_t;
#endif

   typedef    unsigned  short       uint16_t;

#ifndef  __uint32_t
   #define  __uint32_t  1
   typedef    unsigned  int         uint32_t;
#endif

#if  __SASC__!=650
   typedef    unsigned  long long   uint64_t;
#endif
   typedef    signed    long        intptr_t;
   typedef    unsigned  long        uintptr_t;

#elif POSIX
#include <inttypes.h>
#endif

/*------------ FPBool */

typedef unsigned char Boolean ;           /**< @deprecated use FPBool instead                          */
typedef unsigned char FPBool ;            /**< As a boolean type is not available on all platforms     */
#if !defined(__cplusplus)
  #define true        1                     /**< true                                                    */
  #define false       0                     /**< false                                                   */
#endif

#if !defined(TRUE)
  #define TRUE 1
#endif

#if !defined(FALSE)
  #define FALSE 0
#endif                                                                                                      
/*------------- Generic (FilePool) Types */                                                              
#ifdef MACOS9                                                                                          
                                                                                                      
 #define NEWLINE_STR   "\n"               /**< newline separator                                       */
 #define NEWLINE_SIZE  1                  /**< length of newline separator                             */
                                                                                                      
#elif defined(WIN32) || defined(WIN64)

  typedef unsigned char *POINTER;         /**< POINTER defines a generic pointer type                  */
  typedef unsigned short int UINT2;       /**< UINT2 defines a two byte word                           */
  typedef unsigned long int UINT4;        /**< UINT4 defines a four byte word                          */
  #define INT4_MAX    LONG_MAX            /**< for 64 bit environments                                 */
  #define FPINT_MAX   0x7fffffffL
#if defined (__GNUC__)                                                                                  
  typedef int64_t FPLong;                 /**< 8-byte signed integer                                   */
  typedef int32_t FPInt;                  /**< 4-byte signed integer                                   */
  typedef int16_t FPShort;                /**< 2-byte signed integer                                   */
#else                                                                                                  
  typedef __int64 FPLong;                 /**< 8-byte signed integer                                   */
  #ifdef WIN64
    typedef unsigned __int64 FPULong;       /**< 8-byte unsigned integer                                 */
  #else
    typedef unsigned long FPULong;
  #endif
  typedef __int32 FPInt;                  /**< 4-byte signed integer                                   */
  typedef __int16 FPShort;                /**< 2-byte signed integer                                   */
#endif
                                                                                                      
  #define FILESEP       "\\"              /**< file separator                                          */
  #define NEWLINE_STR   "\r\n"            /**< newline separator                                       */
  #define NEWLINE_SIZE  2                 /**< length of newline separator                             */
                                                                                                      
#elif defined(POSIX)

   #if __SASC__==650
          typedef struct {
           unsigned int fplong_value[2];
          } FPLong;
   #elif defined (__IBMC__) || defined (__IBMCPP__) || defined(__SASC__)
      typedef long long FPLong;           /**< 8-byte signed integer                                   */
      typedef unsigned long long FPULong; /**< 8-byte signed integer                                   */
   #else
  typedef int64_t FPLong;                 /**< 8-byte signed integer                                   */
  typedef uint64_t FPULong;        /**< 8-byte unsigned integer                                 */
  //typedef unsigned long FPULong;
   #endif
  typedef int32_t FPInt;                  /**< 4-byte signed integer                                   */
  typedef int16_t FPShort;                /**< 2-byte signed integer                                   */
  #define FPINT_MAX   0x7fffffffL
                                                                                                      
#endif /* WIN32 or POSIX */                                                                              

#define FP_CA_SLEN 64                     /**< The length of a content address represented as a string */
#define FP_CA_BLEN (5*FP_CA_SLEN/8+1)     /**< The length of a content address in canonical format     */
typedef char FPID[FP_CA_SLEN+1];          /**< large enough to hold a string format content address    */
typedef unsigned char FPBINID[FP_CA_BLEN];/**< large enough to hold a canonical format content address */
typedef FPID  FPClipID;                   /**< large enough to hold a C-Clip content address           */
typedef FPID  FPBlobID;                   /**< large enough to hold a Blob content address             */
typedef FPBINID  FPCanonicalClipID;       /**< large enough to hold a C-Clip content address           */
                                                                                                      
/*------------- Export declarations */                                                                  
#if defined (WIN32) || defined(WIN64)

  #undef EXPORT
  #if 1 /* __HPAPI_DLL__ */ 
    #define EXPORT __declspec(dllexport)  
  #else /* !__HPAPI_DLL__ */
    #define EXPORT __declspec(dllimport)
  #endif /* !__HPAPI_DLL__ */
  #undef DECL
  #define DECL __cdecl                    

#elif defined(POSIX)

  /* #define EXPORT          extern */
  #define EXPORT
  #define DECL
#endif

#define FPChar16 unsigned short
#define FPChar32 FPInt

/** @} */ /* Types */

#endif /* __FPTYPES__ */
