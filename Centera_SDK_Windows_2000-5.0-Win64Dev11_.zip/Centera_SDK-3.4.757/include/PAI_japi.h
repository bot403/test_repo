/******************************************************************************\
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * All Rights Reserved
 *
 * PAI_japi.h (header file for class PAI_0005fmodule)
 *
 * PAI module Header File Build Version 3.4.107
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/
/******************************************************************************\
 *
 * The reference implementation of a Pool Access Information (PAI) module
 *.
 * This file defines the interface for the Java API (JNI)
 *
 * DO NOT alter this file when implementing a PAI module!!!
 * 
\******************************************************************************/
#ifndef _Included_PAI_0005fmodule
#define _Included_PAI_0005fmodule

#include <jni.h>

extern "C" {

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_Initialize
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_pai_1module_PAI_1module_PAI_1Initialize
  (JNIEnv *env, jobject t, jstring inRef);

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_GetVersion
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_pai_1module_PAI_1module_PAI_1GetVersion
  (JNIEnv *, jobject, jstring);

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_GetAddress
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_pai_1module_PAI_1module_PAI_1GetAddress
  (JNIEnv *, jobject, jstring);

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_GetAccessInfo
 * Signature: (Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;
 */
JNIEXPORT jobjectArray JNICALL Java_pai_1module_PAI_1module_PAI_1GetAccessInfo
  (JNIEnv *, jobject, jstring, jstring);

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_Create
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_pai_1module_PAI_1module_PAI_1Create
  (JNIEnv *, jobject, jstring);

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_SetAccessInfo
 * Signature: (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_pai_1module_PAI_1module_PAI_1SetAccessInfo
  (JNIEnv *, jobject, jstring, jstring, jstring, jstring);

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_DeleteAccessInfo
 * Signature: (Ljava/lang/String;Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_pai_1module_PAI_1module_PAI_1DeleteAccessInfo
  (JNIEnv *, jobject, jstring, jstring);

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_Update
 * Signature: (Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_pai_1module_PAI_1module_PAI_1Update
  (JNIEnv *, jobject, jstring);

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_Delete
 * Signature: (Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_pai_1module_PAI_1module_PAI_1Delete
  (JNIEnv *, jobject, jstring);

/*
 * Class:     PAI_0005fmodule
 * Method:    PAI_Close
 * Signature: (Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_pai_1module_PAI_1module_PAI_1Close
  (JNIEnv *, jobject, jstring);

} // end of extern "C"

#endif // _Included_PAI_0005fmodule
