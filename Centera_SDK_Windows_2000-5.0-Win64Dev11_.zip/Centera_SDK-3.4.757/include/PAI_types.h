/******************************************************************************\
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * All Rights Reserved
 *
 * PAI_types.h
 *
 * PAI module Header File Build Version 3.4.107
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/
/******************************************************************************\
 *
 * The reference implementation of a Pool Access Information (PAI) module
 *
 * This file defines codes and types used in the API
 *
 * DO NOT alter this file when implementing a PAI module!!!
 * 
\******************************************************************************/
#ifndef __PAI_TYPES_H_
#define __PAI_TYPES_H_

////////////////////////////////////////////////////////////////////////////////
// On Win32 platforms, all files within this DLL are compiled with the 
// PAI_MODULE_EXPORTS symbol defined on the command line. This symbol should not 
// be defined on any project that USES this DLL. This way any other project
// whose source files include this file see PAI_MODULE_API functions as being
// imported from a DLL, wheras this DLL sees symbols defined with this macro as
// being exported.
////////////////////////////////////////////////////////////////////////////////
#if defined(WIN32) || defined(WIN64)
	#ifdef PAI_MODULE_EXPORTS
		#define PAI_MODULE_API __declspec(dllexport)
	#else // PAI_MODULE_EXPORTS not defined
		#ifdef PAI_MODULE_NO_IMPORTS
			#define PAI_MODULE_API
		#else
			#define PAI_MODULE_API __declspec(dllimport)
		#endif
	#endif
#else // WIN32||WIN64not defined
	#define PAI_MODULE_API
    #include <stddef.h>
#endif

////////////////////////////////////////////////////////////////////////////////
// ERROR code definitions
////////////////////////////////////////////////////////////////////////////////
#define PAI_AOK                 0
#define PAI_INTERNAL            1
#define PAI_POOL_EXISTS         2
#define PAI_NO_POOL             3
#define PAI_NO_ACCESS           4
#define PAI_BAD_REFERENCE       5
#define PAI_STRING_OVERFLOW     6
#define PAI_NO_ADDRESS          7
#define PAI_UNKNOWN_SECTION     8
#define PAI_USE_ANONYMOUS       9

////////////////////////////////////////////////////////////////////////////////
// Typedefs
////////////////////////////////////////////////////////////////////////////////
typedef long PAIRef;

#if defined(WIN64)
typedef size_t PAI_INT; //long long PAI_LONG
typedef size_t PAI_UNSIGNED_SHORT;
typedef size_t PAI_UNSIGNED_INT;
#elif !defined(WIN32)
typedef size_t PAI_INT; //long long PAI_LONG
typedef size_t PAI_UNSIGNED_SHORT;
typedef size_t PAI_UNSIGNED_INT;
#else
typedef int PAI_INT; //int PAI_LONG;
typedef unsigned short PAI_UNSIGNED_SHORT;
typedef unsigned int PAI_UNSIGNED_INT;
#endif

#ifndef __MVS__                   
#define NXLT(a) a
#endif  // __MVS__

#endif // __PAI_TYPES_H_
