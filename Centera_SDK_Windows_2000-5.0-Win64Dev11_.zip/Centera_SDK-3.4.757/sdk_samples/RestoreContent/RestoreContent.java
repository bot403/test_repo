import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import com.filepool.fplibrary.FPClip;
import com.filepool.fplibrary.FPLibraryConstants;
import com.filepool.fplibrary.FPLibraryException;
import com.filepool.fplibrary.FPPool;
import com.filepool.fplibrary.FPTag;

/*****************************************************************************
 * 
 * Copyright (c) 2001-2006 EMC Corporation All Rights Reserved
 * 
 * RestoreContent.java
 * 
 * Using the Centera Java API to restore a client-side saved C-Clip and it's blobs
 * utilizing the raw access.
 * 
 * This sourcefile contains the intellectual property of EMC Corporation or
 * is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to
 * the terms and conditions of the License Agreement.
 *  
 ****************************************************************************/

/**
 * <p>
 * Title: RestoreContent
 * </p>
 * <p>
 * Description: Using the Centera Java API to restore a client-side saved C-Clip
 * and it's blobs utilizing raw access.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * <p>
 * Company: EMC Corp.
 * </p>
 */
public class RestoreContent {

	/**
	 * main
	 * 
	 */
	public static void main(String[] args) {
		int exitCode = 0;
		String appName="Restore Content Sample";
	    String appVersion="3.1";
		String poolAddress = "us1cas1.centera.org,us1cas2.centera.org";
		int CLIP_OPTIONS = 0;
		InputStreamReader inputReader = new InputStreamReader(System.in);
		BufferedReader stdin = new BufferedReader(inputReader);

		try {

		 /*Stores your application's name and version for registration on Centera
	       This call should be made one time, before the FPPoolOpen() call,
	       for each application that interfaces with centera
	       *
	       Applications can also be registered via the environment variables 
	       FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
	       will override what is set through environment variable.
		   */
		    FPPool.RegisterApplication(appName,appVersion);
			// Prompt user for cluster to connect to
			System.out.print("Address of cluster[" + poolAddress + "]: ");
			String answer = stdin.readLine();

			if (!answer.equals(""))
				poolAddress = answer;

			System.out.println(
				"Connecting to Centera cluster(" + poolAddress + ")");

			// New feature for 2.3 lazy pool open
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_OPENSTRATEGY,
				FPLibraryConstants.FP_LAZY_OPEN);

			// open cluster connection
			FPPool thePool = new FPPool(poolAddress);

			// Prompt user for file name to restore to centera
			System.out.print("File name to restore: ");
			String filename = stdin.readLine();

			if (filename.equals(""))
				throw new IllegalArgumentException("Invalid answer.");

			File cdfDataFile = new File(filename);

			String tagPath = filename.substring(0, filename.lastIndexOf(".")) + ".tag";
			String clipID = filename.substring(filename.lastIndexOf(File.separatorChar) + 1,
					filename.lastIndexOf("."));

			if (!cdfDataFile.canRead()) {
				throw new IllegalArgumentException(
					"Could not open CDF data file \""
						+ filename + "\" for reading.");
			}

			// Create new in-memory C-Clip tree using the input file data.
			FileInputStream cdfDataStream = new FileInputStream(cdfDataFile);

			FPClip theClip =
				new FPClip(thePool, clipID, cdfDataStream, CLIP_OPTIONS);

			// now read back any blobs on the Tags
			FPTag theTag;
			FileInputStream theFile;
			int tagNum = 0;
			
			while ((theTag = theClip.FetchNext()) != null)	
			{
				int blobStatus = theTag.BlobExists();
				
				if (blobStatus != 0)
				{
					if (blobStatus == 1)
					{
						// Available to read
						theFile = new FileInputStream(tagPath + tagNum);
						theTag.BlobWrite(theFile);
						theFile.close();
						System.out.println("Retrieved blob content from " + tagPath + tagNum);
					}
					else
						System.out.println("Blob on Tag " + tagNum
								+ " is currently unavailable and has NOT been exported.");					
				}
				theTag.Close();
				tagNum++;
			}
			// The returned clip ID should match the provided clip ID 
			// because the content should be the same.
			System.out.print(
				"Restoring clip ID: " + clipID + " to the Centera...");
			String theNewClipID = theClip.Write();
			System.out.println(" Ok.");

			if (!theNewClipID.equals(clipID)) {
				throw new IllegalArgumentException(
					"The newly-stored ClipID \""
						+ theNewClipID
						+ "\" does not match the stored clipID \""
						+ clipID
						+ "\".");
			}

			theClip.Close();
			cdfDataStream.close();
			inputReader.close();
			stdin.close();

			System.out.println("C-Clip successfully restored.");

			// Always close the Pool connection when finished.  Not a
			// good practice to open and close for each transaction.
			thePool.Close();
			System.out.println(
				"\nClosed connection to Centera cluster (" + poolAddress + ")");

		} catch (FPLibraryException e) {
			exitCode = e.getErrorCode();
			System.err.println(
				"Centera Error: " + e.getMessage() + "(" + exitCode + ")");
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		} catch (IOException e) {
			System.err.println("I/O Error occured: " + e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		}

		System.exit(exitCode);
	}
}
